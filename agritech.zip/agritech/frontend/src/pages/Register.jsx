import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import axios from 'axios';
import { toast } from 'react-toastify';
import {
  FaLeaf, FaUser, FaEnvelope, FaLock, FaPhone,
  FaEye, FaEyeSlash, FaArrowRight, FaCheckCircle,
} from 'react-icons/fa';

const LIME = {
  dark:    '#3f6212',
  mid:     '#4d7c0f',
  base:    '#65a30d',
  light:   '#84cc16',
  pale:    '#bef264',
  accent:  '#d9f99d',
  xlight:  '#ecfccb',
  xxlight: '#f7fee7',
};

const InputField = ({ icon: Icon, label, type = 'text', name, value, onChange, placeholder, required, extra }) => {
  const [focused, setFocused] = useState(false);
  return (
    <div style={{ marginBottom: '1rem' }}>
      <label style={{ display: 'block', marginBottom: '5px', fontWeight: 600, fontSize: '0.78rem', color: '#555', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
        {label} {required && <span style={{ color: '#ef4444' }}>*</span>}
      </label>
      <div style={{ position: 'relative' }}>
        {Icon && (
          <Icon style={{
            position: 'absolute', left: '13px', top: '50%',
            transform: 'translateY(-50%)',
            color: focused ? LIME.base : '#bbb',
            fontSize: '13px',
            transition: 'color 0.2s',
          }} />
        )}
        <input
          type={type}
          name={name}
          value={value}
          onChange={onChange}
          required={required}
          placeholder={placeholder}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          style={{
            width: '100%',
            padding: `11px 12px 11px ${Icon ? '38px' : '12px'}`,
            border: `1.5px solid ${focused ? LIME.light : '#e5e7eb'}`,
            borderRadius: '12px',
            fontSize: '0.875rem',
            outline: 'none',
            transition: 'all 0.2s',
            background: focused ? 'white' : LIME.xxlight,
            boxShadow: focused ? `0 0 0 3px rgba(132,204,22,0.18)` : 'none',
          }}
        />
        {extra}
      </div>
    </div>
  );
};

const Register = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [formData, setFormData] = useState({
    name: '', email: '', password: '', confirmPassword: '', phone: '', role: 'farmer',
  });

  const handleChange = (e) => setFormData({ ...formData, [e.target.name]: e.target.value });

  const passwordStrength = () => {
    const p = formData.password;
    if (!p) return null;
    if (p.length < 6) return { label: 'Too short', color: '#ef4444', width: '25%' };
    if (p.length < 8) return { label: 'Weak', color: '#f59e0b', width: '50%' };
    if (/[A-Z]/.test(p) && /[0-9]/.test(p)) return { label: 'Strong', color: LIME.dark, width: '100%' };
    return { label: 'Fair', color: LIME.base, width: '75%' };
  };

  const strength = passwordStrength();

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (formData.password !== formData.confirmPassword) {
      toast.error('Passwords do not match');
      return;
    }
    if (formData.password.length < 6) {
      toast.error('Password must be at least 6 characters');
      return;
    }
    setLoading(true);
    try {
      await axios.post('http://localhost:5000/api/auth/register', {
        name: formData.name,
        email: formData.email,
        password: formData.password,
        phone: formData.phone,
        role: formData.role,
      });
      toast.success('Account created! Please sign in.');
      navigate('/login');
    } catch (error) {
      if (error.response) {
        toast.error(error.response.data.message || 'Registration failed');
      } else if (error.request) {
        toast.error('Cannot reach the server. Please make sure the backend is running.');
      } else {
        toast.error('Registration failed: ' + error.message);
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: `linear-gradient(135deg, ${LIME.xlight} 0%, ${LIME.accent} 100%)`,
      padding: '2rem 1rem',
    }}>
      <div style={{ width: '100%', maxWidth: '500px' }} className="fade-in-up">
        {/* Brand */}
        <div className="d-flex align-items-center gap-2 mb-4 justify-content-center">
          <div style={{
            background: `linear-gradient(135deg, ${LIME.dark}, ${LIME.base})`,
            borderRadius: '12px',
            padding: '9px 11px',
            display: 'inline-flex',
            boxShadow: `0 4px 12px rgba(101,163,13,0.3)`,
          }}>
            <FaLeaf style={{ color: LIME.pale, fontSize: '20px' }} />
          </div>
          <span style={{ fontWeight: 800, fontSize: '1.4rem', color: LIME.dark }}>
            Agri<span style={{ color: LIME.base }}>Tech</span>
          </span>
        </div>

        <div style={{
          background: 'white',
          borderRadius: '24px',
          padding: '2.5rem',
          boxShadow: '0 12px 48px rgba(0,0,0,0.1)',
          border: `1px solid ${LIME.accent}`,
          overflow: 'hidden',
          position: 'relative',
        }}>
          {/* top accent bar */}
          <div style={{
            position: 'absolute', top: 0, left: 0, right: 0,
            height: 4,
            background: `linear-gradient(90deg, ${LIME.dark}, ${LIME.light})`,
          }} />

          <h3 style={{ fontWeight: 700, color: LIME.dark, marginBottom: '0.3rem', marginTop: '0.5rem' }}>
            Create your account
          </h3>
          <p style={{ color: '#888', fontSize: '0.875rem', marginBottom: '1.75rem' }}>
            Join thousands of farmers using AgriTech
          </p>

          <form onSubmit={handleSubmit}>
            <InputField icon={FaUser}     label="Full Name"     name="name"  value={formData.name}  onChange={handleChange} placeholder="Your full name"   required />
            <InputField icon={FaEnvelope} label="Email"         type="email" name="email" value={formData.email} onChange={handleChange} placeholder="your@email.com" required />

            {/* Password */}
            <div style={{ marginBottom: '0.5rem' }}>
              <label style={{ display: 'block', marginBottom: '5px', fontWeight: 600, fontSize: '0.78rem', color: '#555', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
                Password <span style={{ color: '#ef4444' }}>*</span>
              </label>
              <div style={{ position: 'relative' }}>
                <FaLock style={{ position: 'absolute', left: '13px', top: '50%', transform: 'translateY(-50%)', color: '#bbb', fontSize: '13px' }} />
                <input
                  type={showPassword ? 'text' : 'password'}
                  name="password"
                  value={formData.password}
                  onChange={handleChange}
                  required
                  placeholder="Minimum 6 characters"
                  style={{
                    width: '100%', padding: '11px 40px 11px 38px',
                    border: '1.5px solid #e5e7eb', borderRadius: '12px',
                    fontSize: '0.875rem', outline: 'none', background: LIME.xxlight,
                  }}
                  onFocus={e => { e.target.style.borderColor = LIME.light; e.target.style.boxShadow = `0 0 0 3px rgba(132,204,22,0.18)`; e.target.style.background = 'white'; }}
                  onBlur={e => { e.target.style.borderColor = '#e5e7eb'; e.target.style.boxShadow = 'none'; e.target.style.background = LIME.xxlight; }}
                />
                <button type="button" onClick={() => setShowPassword(!showPassword)}
                  style={{ position: 'absolute', right: '12px', top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', cursor: 'pointer', color: '#aaa', padding: 0 }}>
                  {showPassword ? <FaEyeSlash size={14} /> : <FaEye size={14} />}
                </button>
              </div>
            </div>

            {/* Strength bar */}
            {strength && (
              <div style={{ marginBottom: '1rem' }}>
                <div style={{ height: 4, background: '#f0f0f0', borderRadius: 4, overflow: 'hidden' }}>
                  <div style={{ height: '100%', width: strength.width, background: strength.color, borderRadius: 4, transition: 'width 0.3s ease' }} />
                </div>
                <small style={{ color: strength.color, fontSize: '0.72rem', fontWeight: 600 }}>{strength.label} password</small>
              </div>
            )}

            {/* Confirm password */}
            <div style={{ marginBottom: '1rem' }}>
              <label style={{ display: 'block', marginBottom: '5px', fontWeight: 600, fontSize: '0.78rem', color: '#555', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
                Confirm Password <span style={{ color: '#ef4444' }}>*</span>
              </label>
              <div style={{ position: 'relative' }}>
                <FaLock style={{ position: 'absolute', left: '13px', top: '50%', transform: 'translateY(-50%)', color: '#bbb', fontSize: '13px' }} />
                <input
                  type={showConfirm ? 'text' : 'password'}
                  name="confirmPassword"
                  value={formData.confirmPassword}
                  onChange={handleChange}
                  required
                  placeholder="Repeat your password"
                  style={{
                    width: '100%', padding: '11px 40px 11px 38px',
                    border: `1.5px solid ${formData.confirmPassword && formData.confirmPassword !== formData.password ? '#ef4444' : '#e5e7eb'}`,
                    borderRadius: '12px', fontSize: '0.875rem', outline: 'none', background: LIME.xxlight,
                  }}
                  onFocus={e => { e.target.style.borderColor = LIME.light; e.target.style.background = 'white'; }}
                  onBlur={e => { e.target.style.borderColor = formData.confirmPassword && formData.confirmPassword !== formData.password ? '#ef4444' : '#e5e7eb'; e.target.style.background = LIME.xxlight; }}
                />
                <button type="button" onClick={() => setShowConfirm(!showConfirm)}
                  style={{ position: 'absolute', right: '12px', top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', cursor: 'pointer', color: '#aaa', padding: 0 }}>
                  {showConfirm ? <FaEyeSlash size={14} /> : <FaEye size={14} />}
                </button>
                {formData.confirmPassword && formData.confirmPassword === formData.password && (
                  <FaCheckCircle style={{ position: 'absolute', right: '36px', top: '50%', transform: 'translateY(-50%)', color: LIME.base, fontSize: '13px' }} />
                )}
              </div>
            </div>

            <InputField icon={FaPhone} label="Phone Number" type="tel" name="phone" value={formData.phone} onChange={handleChange} placeholder="Optional" />

            {/* Role selector */}
            <div style={{ marginBottom: '1.75rem' }}>
              <label style={{ display: 'block', marginBottom: '8px', fontWeight: 600, fontSize: '0.78rem', color: '#555', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
                I am a...
              </label>
              <div style={{ display: 'flex', gap: '10px' }}>
                {[
                  { value: 'farmer', label: '🌾 Farmer', desc: 'Manage my farm' },
                  { value: 'expert', label: '👨‍🌾 Expert', desc: 'Advise farmers' },
                ].map(opt => (
                  <label
                    key={opt.value}
                    style={{
                      flex: 1, cursor: 'pointer',
                      border: `2px solid ${formData.role === opt.value ? LIME.light : '#e5e7eb'}`,
                      borderRadius: '14px', padding: '12px',
                      background: formData.role === opt.value ? LIME.xlight : 'white',
                      transition: 'all 0.2s ease',
                      textAlign: 'center',
                      boxShadow: formData.role === opt.value ? `0 0 0 3px rgba(132,204,22,0.18)` : 'none',
                    }}
                  >
                    <input
                      type="radio"
                      name="role"
                      value={opt.value}
                      checked={formData.role === opt.value}
                      onChange={handleChange}
                      style={{ display: 'none' }}
                    />
                    <div style={{ fontWeight: 700, fontSize: '0.9rem', color: formData.role === opt.value ? LIME.dark : '#555' }}>
                      {opt.label}
                    </div>
                    <div style={{ fontSize: '0.75rem', color: '#888', marginTop: '2px' }}>{opt.desc}</div>
                  </label>
                ))}
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              style={{
                width: '100%', padding: '13px',
                background: loading ? '#d1d5db' : `linear-gradient(135deg, ${LIME.dark}, ${LIME.light})`,
                color: 'white', border: 'none', borderRadius: '12px',
                fontSize: '0.95rem', fontWeight: 700, cursor: loading ? 'not-allowed' : 'pointer',
                display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px',
                boxShadow: loading ? 'none' : `0 4px 16px rgba(101,163,13,0.35)`,
                transition: 'all 0.25s ease',
              }}
              onMouseEnter={e => { if (!loading) e.currentTarget.style.transform = 'translateY(-2px)'; }}
              onMouseLeave={e => { e.currentTarget.style.transform = 'translateY(0)'; }}
            >
              {loading ? (
                <>
                  <span style={{
                    width: 16, height: 16, border: '2px solid rgba(255,255,255,0.4)',
                    borderTopColor: 'white', borderRadius: '50%',
                    animation: 'spin 0.8s linear infinite', display: 'inline-block',
                  }} />
                  Creating account...
                </>
              ) : (
                <>Create Account <FaArrowRight size={13} /></>
              )}
            </button>
          </form>

          <p style={{ textAlign: 'center', marginTop: '1.5rem', fontSize: '0.875rem', color: '#666' }}>
            Already have an account?{' '}
            <Link to="/login" style={{ color: LIME.base, fontWeight: 700, textDecoration: 'none' }}>
              Sign in
            </Link>
          </p>
        </div>
      </div>

      <style>{`
        @keyframes spin { to { transform: rotate(360deg); } }
        .fade-in-up { animation: fadeInUp 0.5s ease-out; }
        @keyframes fadeInUp {
          from { opacity: 0; transform: translateY(20px); }
          to   { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  );
};

export default Register;
