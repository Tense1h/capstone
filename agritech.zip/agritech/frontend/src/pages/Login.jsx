import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import axios from 'axios';
import { toast } from 'react-toastify';
import { FaLeaf, FaEnvelope, FaLock, FaEye, FaEyeSlash, FaArrowRight } from 'react-icons/fa';

const LIME = {
  dark:    '#3f6212',
  mid:     '#4d7c0f',
  base:    '#65a30d',
  light:   '#84cc16',
  pale:    '#bef264',
  accent:  '#d9f99d',
  xlight:  '#ecfccb',
  xxlight: '#f7fee7',
};

const Login = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const response = await axios.post('http://localhost:5000/api/auth/login', { email, password });
      if (response.data.token) {
        localStorage.setItem('token', response.data.token);
        localStorage.setItem('user', JSON.stringify(response.data));
        toast.success(`Welcome back, ${response.data.name}!`);
        window.location.href = '/dashboard';
      } else {
        toast.error('No token received from server');
      }
    } catch (error) {
      if (error.response) {
        toast.error(error.response.data.message || 'Login failed');
      } else if (error.request) {
        toast.error('Cannot reach the server. Please make sure the backend is running.');
      } else {
        toast.error('Login failed: ' + error.message);
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{
      minHeight: '100vh',
      display: 'flex',
      background: `linear-gradient(135deg, ${LIME.xlight} 0%, ${LIME.accent} 100%)`,
    }}>
      {/* ── Left decorative panel ── */}
      <div
        className="d-none d-lg-flex flex-column justify-content-center align-items-center"
        style={{
          width: '45%',
          background: `linear-gradient(160deg, ${LIME.dark} 0%, ${LIME.base} 100%)`,
          padding: '3rem',
          color: 'white',
          position: 'relative',
          overflow: 'hidden',
        }}
      >
        {/* decorative circles */}
        <div style={{
          position: 'absolute', top: '-60px', right: '-60px',
          width: 220, height: 220, borderRadius: '50%',
          background: 'rgba(255,255,255,0.07)',
        }} />
        <div style={{
          position: 'absolute', bottom: '-40px', left: '-40px',
          width: 160, height: 160, borderRadius: '50%',
          background: 'rgba(255,255,255,0.05)',
        }} />

        <div className="text-center fade-in-up" style={{ position: 'relative' }}>
          <div style={{
            background: 'rgba(255,255,255,0.15)',
            borderRadius: '20px',
            padding: '20px',
            display: 'inline-flex',
            marginBottom: '1.5rem',
            border: `1px solid rgba(255,255,255,0.2)`,
          }}>
            <FaLeaf style={{ fontSize: '48px', color: LIME.pale }} />
          </div>
          <h2 style={{ fontWeight: 800, fontSize: '2rem', marginBottom: '0.75rem' }}>
            Agri<span style={{ color: LIME.pale }}>Tech</span>
          </h2>
          <p style={{ color: 'rgba(255,255,255,0.75)', fontSize: '1rem', maxWidth: '280px', lineHeight: 1.75 }}>
            Smart farming tools to help you grow better, faster, and smarter.
          </p>
          <div style={{ marginTop: '2.5rem', display: 'flex', flexDirection: 'column', gap: '0.85rem' }}>
            {['Real-time weather insights', 'Crop growth tracking', 'Expert community forum'].map((item, i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'center', gap: '10px', color: 'rgba(255,255,255,0.88)' }}>
                <div style={{
                  width: 8, height: 8, borderRadius: '50%',
                  background: LIME.pale, flexShrink: 0,
                }} />
                <span style={{ fontSize: '0.9rem' }}>{item}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ── Right form panel ── */}
      <div style={{
        flex: 1,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '2rem',
      }}>
        <div style={{ width: '100%', maxWidth: '420px' }} className="fade-in-up">
          {/* Mobile brand */}
          <div className="d-flex d-lg-none align-items-center gap-2 mb-4 justify-content-center">
            <div style={{
              background: LIME.base,
              borderRadius: '10px',
              padding: '7px 9px',
              display: 'inline-flex',
            }}>
              <FaLeaf style={{ color: LIME.pale, fontSize: '20px' }} />
            </div>
            <span style={{ fontWeight: 800, fontSize: '1.3rem', color: LIME.dark }}>AgriTech</span>
          </div>

          <div style={{
            background: 'white',
            borderRadius: '24px',
            padding: '2.5rem',
            boxShadow: '0 12px 48px rgba(0,0,0,0.1)',
            border: `1px solid ${LIME.accent}`,
          }}>
            {/* Header accent bar */}
            <div style={{
              height: 4,
              borderRadius: '4px',
              background: `linear-gradient(90deg, ${LIME.dark}, ${LIME.light})`,
              marginBottom: '1.75rem',
              marginLeft: '-2.5rem',
              marginRight: '-2.5rem',
              marginTop: '-2.5rem',
              borderRadius: '24px 24px 0 0',
            }} />

            <h3 style={{ fontWeight: 700, color: LIME.dark, marginBottom: '0.4rem' }}>Welcome back</h3>
            <p style={{ color: '#888', fontSize: '0.9rem', marginBottom: '2rem' }}>
              Sign in to your account to continue
            </p>

            <form onSubmit={handleSubmit}>
              {/* Email */}
              <div style={{ marginBottom: '1.25rem' }}>
                <label style={{ display: 'block', marginBottom: '6px', fontWeight: 600, fontSize: '0.8rem', color: '#555', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
                  Email address
                </label>
                <div style={{ position: 'relative' }}>
                  <FaEnvelope style={{
                    position: 'absolute', left: '14px', top: '50%',
                    transform: 'translateY(-50%)', color: '#bbb', fontSize: '14px',
                  }} />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    placeholder="your@email.com"
                    style={{
                      width: '100%', padding: '12px 12px 12px 42px',
                      border: '1.5px solid #e5e7eb', borderRadius: '12px',
                      fontSize: '0.9rem', outline: 'none', transition: 'all 0.2s',
                      background: LIME.xxlight,
                    }}
                    onFocus={e => { e.target.style.borderColor = LIME.light; e.target.style.boxShadow = `0 0 0 3px rgba(132,204,22,0.18)`; e.target.style.background = 'white'; }}
                    onBlur={e => { e.target.style.borderColor = '#e5e7eb'; e.target.style.boxShadow = 'none'; e.target.style.background = LIME.xxlight; }}
                  />
                </div>
              </div>

              {/* Password */}
              <div style={{ marginBottom: '1.75rem' }}>
                <label style={{ display: 'block', marginBottom: '6px', fontWeight: 600, fontSize: '0.8rem', color: '#555', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
                  Password
                </label>
                <div style={{ position: 'relative' }}>
                  <FaLock style={{
                    position: 'absolute', left: '14px', top: '50%',
                    transform: 'translateY(-50%)', color: '#bbb', fontSize: '14px',
                  }} />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    placeholder="Enter your password"
                    style={{
                      width: '100%', padding: '12px 42px 12px 42px',
                      border: '1.5px solid #e5e7eb', borderRadius: '12px',
                      fontSize: '0.9rem', outline: 'none', transition: 'all 0.2s',
                      background: LIME.xxlight,
                    }}
                    onFocus={e => { e.target.style.borderColor = LIME.light; e.target.style.boxShadow = `0 0 0 3px rgba(132,204,22,0.18)`; e.target.style.background = 'white'; }}
                    onBlur={e => { e.target.style.borderColor = '#e5e7eb'; e.target.style.boxShadow = 'none'; e.target.style.background = LIME.xxlight; }}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    style={{
                      position: 'absolute', right: '12px', top: '50%',
                      transform: 'translateY(-50%)', background: 'none',
                      border: 'none', cursor: 'pointer', color: '#aaa', padding: 0,
                    }}
                  >
                    {showPassword ? <FaEyeSlash size={15} /> : <FaEye size={15} />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                style={{
                  width: '100%', padding: '13px',
                  background: loading ? '#d1d5db' : `linear-gradient(135deg, ${LIME.dark}, ${LIME.light})`,
                  color: 'white', border: 'none', borderRadius: '12px',
                  fontSize: '0.95rem', fontWeight: 700, cursor: loading ? 'not-allowed' : 'pointer',
                  display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px',
                  transition: 'all 0.25s ease',
                  boxShadow: loading ? 'none' : `0 4px 16px rgba(101,163,13,0.35)`,
                }}
                onMouseEnter={e => { if (!loading) e.currentTarget.style.transform = 'translateY(-2px)'; }}
                onMouseLeave={e => { e.currentTarget.style.transform = 'translateY(0)'; }}
              >
                {loading ? (
                  <>
                    <span style={{
                      width: 16, height: 16, border: '2px solid rgba(255,255,255,0.4)',
                      borderTopColor: 'white', borderRadius: '50%',
                      animation: 'spin 0.8s linear infinite', display: 'inline-block',
                    }} />
                    Signing in...
                  </>
                ) : (
                  <>Sign In <FaArrowRight size={13} /></>
                )}
              </button>
            </form>

            <p style={{ textAlign: 'center', marginTop: '1.5rem', fontSize: '0.875rem', color: '#666' }}>
              Don't have an account?{' '}
              <Link to="/register" style={{ color: LIME.base, fontWeight: 700, textDecoration: 'none' }}>
                Create one free
              </Link>
            </p>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes spin { to { transform: rotate(360deg); } }
        .fade-in-up { animation: fadeInUp 0.5s ease-out; }
        @keyframes fadeInUp {
          from { opacity: 0; transform: translateY(20px); }
          to   { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  );
};

export default Login;
