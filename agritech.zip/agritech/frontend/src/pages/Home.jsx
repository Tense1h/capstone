import React from 'react';
import { Link } from 'react-router-dom';
import { Container, Row, Col, Button, Card } from 'react-bootstrap';
import {
  FaLeaf, FaChartLine, FaComments, FaCloudSun, FaTractor,
  FaShieldAlt, FaSeedling, FaUsers, FaHeadset, FaRocket,
  FaArrowRight, FaCheckCircle, FaStar, FaUserGraduate,
} from 'react-icons/fa';
import Navbar from '../components/Layout/Navbar';
import Footer from '../components/Layout/Footer';

const LIME = {
  dark:      '#3f6212',
  mid:       '#4d7c0f',
  base:      '#65a30d',
  light:     '#84cc16',
  bright:    '#a3e635',
  pale:      '#bef264',
  accent:    '#d9f99d',
  xlight:    '#ecfccb',
  xxlight:   '#f7fee7',
};

const Home = () => {
  const heroImageUrl = '/src/assets/homeAgri.jpg';

  const features = [
    { icon: <FaTractor size={32} style={{ color: LIME.base }} />,    title: 'Farm Management',  desc: 'Track your farms, crops, and resources in one place',          color: LIME.xxlight },
    { icon: <FaCloudSun size={32} style={{ color: '#0284c7' }} />,   title: 'Weather Insights', desc: 'Real-time weather with agricultural recommendations',           color: '#e0f2fe' },
    { icon: <FaChartLine size={32} style={{ color: '#d97706' }} />,  title: 'Analytics',        desc: 'Data-driven decisions for better yields',                      color: '#fef3c7' },
    { icon: <FaComments size={32} style={{ color: '#7c3aed' }} />,   title: 'Community Forum',  desc: 'Connect with experts and fellow farmers',                      color: '#ede9fe' },
    { icon: <FaSeedling size={32} style={{ color: LIME.mid }} />,    title: 'Expert Advice',    desc: 'Get guidance from agricultural experts',                       color: LIME.xlight },
    { icon: <FaShieldAlt size={32} style={{ color: '#1d4ed8' }} />,  title: 'Secure Platform',  desc: 'Your data is safe with role-based access',                    color: '#eff6ff' },
  ];

  const stats = [
    { number: '10K+', label: 'Active Farmers',    icon: <FaUsers        style={{ color: LIME.base }} /> },
    { number: '500+', label: 'Expert Advisors',   icon: <FaUserGraduate style={{ color: '#d97706' }} /> },
    { number: '50K+', label: 'Crops Tracked',     icon: <FaSeedling     style={{ color: LIME.light }} /> },
    { number: '98%',  label: 'Satisfaction Rate', icon: <FaStar         style={{ color: '#f59e0b' }} /> },
  ];

  return (
    <>
      <Navbar />

      {/* ── Hero ── */}
      <div style={{
        background: `linear-gradient(135deg, ${LIME.xlight} 0%, ${LIME.accent} 100%)`,
        padding: '80px 0',
        position: 'relative',
        overflow: 'hidden',
      }}>
        {/* decorative blobs */}
        <div style={{
          position: 'absolute', top: '-80px', right: '-80px',
          width: 320, height: 320,
          borderRadius: '50%',
          background: `radial-gradient(circle, ${LIME.pale}55, transparent 70%)`,
          pointerEvents: 'none',
        }} />
        <div style={{
          position: 'absolute', bottom: '-60px', left: '-60px',
          width: 240, height: 240,
          borderRadius: '50%',
          background: `radial-gradient(circle, ${LIME.accent}88, transparent 70%)`,
          pointerEvents: 'none',
        }} />

        <Container style={{ position: 'relative' }}>
          <Row className="align-items-center">
            <Col lg={6} className="mb-5 mb-lg-0">
              <div className="fade-in-up">
                <div className="d-flex align-items-center gap-2 mb-3">
                  <FaLeaf size={36} style={{ color: LIME.base }} />
                  <span style={{
                    background: `rgba(101,163,13,0.14)`,
                    padding: '4px 14px',
                    borderRadius: '20px',
                    fontSize: '13px',
                    color: LIME.dark,
                    fontWeight: 600,
                    border: `1px solid ${LIME.pale}`,
                  }}>
                    Smart Farming Solution
                  </span>
                </div>

                <h1 className="display-3 fw-bold mb-4" style={{
                  background: `linear-gradient(135deg, ${LIME.dark}, ${LIME.light})`,
                  WebkitBackgroundClip: 'text',
                  backgroundClip: 'text',
                  color: 'transparent',
                  lineHeight: 1.15,
                }}>
                  Smart Farming for Modern Agriculture
                </h1>

                <p className="lead text-muted mb-4" style={{ fontSize: '1.15rem', lineHeight: 1.75 }}>
                  Empower your farming journey with real-time data, expert insights, and community support.
                  Make evidence-based decisions and maximize your agricultural productivity.
                </p>

                <div className="d-flex flex-wrap gap-3">
                  <Button
                    as={Link}
                    to="/register"
                    size="lg"
                    className="btn-gradient px-4 rounded-pill"
                    style={{ fontWeight: 700 }}
                  >
                    Get Started Free <FaArrowRight className="ms-2" />
                  </Button>
                  <Button
                    as={Link}
                    to="/login"
                    variant="outline-success"
                    size="lg"
                    className="rounded-pill"
                  >
                    Sign In
                  </Button>
                </div>

                <div className="d-flex align-items-center gap-2 mt-4">
                  <FaCheckCircle style={{ color: LIME.base }} />
                  <span className="small text-muted">Free forever · No credit card required</span>
                </div>
              </div>
            </Col>

            <Col lg={6} className="text-center">
              <div style={{ position: 'relative' }}>
                <div style={{
                  position: 'absolute', inset: -12,
                  borderRadius: '28px',
                  background: `linear-gradient(135deg, ${LIME.pale}55, ${LIME.accent}55)`,
                  zIndex: 0,
                }} />
                <img
                  src={heroImageUrl}
                  alt="Smart Farming"
                  className="img-fluid shadow-lg"
                  style={{
                    maxHeight: '450px',
                    objectFit: 'cover',
                    width: '100%',
                    borderRadius: '20px',
                    position: 'relative',
                    zIndex: 1,
                    border: `3px solid ${LIME.pale}`,
                  }}
                  onError={(e) => {
                    e.target.onerror = null;
                    e.target.src = 'https://images.unsplash.com/photo-1592982537447-2f6c6a7a9f5c?w=600&h=400&fit=crop';
                  }}
                />
                {/* floating badge */}
                <div style={{
                  position: 'absolute',
                  bottom: '24px',
                  left: '24px',
                  background: 'white',
                  borderRadius: '14px',
                  padding: '12px 18px',
                  boxShadow: '0 6px 20px rgba(0,0,0,0.12)',
                  zIndex: 2,
                  border: `2px solid ${LIME.accent}`,
                }}>
                  <div className="d-flex align-items-center gap-3">
                    <div style={{
                      background: LIME.xlight,
                      borderRadius: '10px',
                      padding: '8px',
                      display: 'flex',
                    }}>
                      <FaLeaf style={{ color: LIME.base, fontSize: '20px' }} />
                    </div>
                    <div>
                      <div className="fw-bold" style={{ color: LIME.dark, fontSize: '0.9rem' }}>Trusted by</div>
                      <div className="small text-muted">10,000+ farmers</div>
                    </div>
                  </div>
                </div>
              </div>
            </Col>
          </Row>
        </Container>
      </div>

      {/* ── Stats ── */}
      <Container className="py-5">
        <Row className="g-4 justify-content-center">
          {stats.map((stat, idx) => (
            <Col md={3} sm={6} key={idx}>
              <Card className="text-center border-0 shadow-sm card-hover" style={{
                background: `linear-gradient(135deg, #fff, ${LIME.xxlight})`,
                borderTop: `3px solid ${LIME.pale} !important`,
              }}>
                <Card.Body className="py-4">
                  <div className="mb-3" style={{ fontSize: '1.6rem' }}>{stat.icon}</div>
                  <h2 className="mb-0 fw-bold" style={{ color: LIME.dark }}>{stat.number}</h2>
                  <p className="text-muted mb-0 small">{stat.label}</p>
                </Card.Body>
              </Card>
            </Col>
          ))}
        </Row>
      </Container>

      {/* ── Features ── */}
      <Container className="py-5">
        <div className="text-center mb-5">
          <span style={{
            background: `rgba(101,163,13,0.12)`,
            color: LIME.dark,
            padding: '4px 16px',
            borderRadius: '20px',
            fontSize: '0.8rem',
            fontWeight: 600,
            border: `1px solid ${LIME.pale}`,
          }}>
            FEATURES
          </span>
          <h2 className="gradient-text fw-bold mt-3 mb-2">Powerful Tools for Smart Farmers</h2>
          <p className="text-muted">Everything you need to manage your farm efficiently</p>
        </div>
        <Row className="g-4">
          {features.map((feature, idx) => (
            <Col md={6} lg={4} key={idx}>
              <Card className="h-100 border-0 shadow-sm card-hover" style={{ borderRadius: '18px' }}>
                <Card.Body className="p-4">
                  <div className="mb-3 p-3 rounded-3 d-inline-flex" style={{ backgroundColor: feature.color }}>
                    {feature.icon}
                  </div>
                  <Card.Title className="h5 mb-2 fw-bold">{feature.title}</Card.Title>
                  <Card.Text className="text-muted" style={{ fontSize: '0.9rem' }}>{feature.desc}</Card.Text>
                </Card.Body>
              </Card>
            </Col>
          ))}
        </Row>
      </Container>

      {/* ── CTA ── */}
      <div className="gradient-bg text-white py-5 mt-4" style={{ position: 'relative', overflow: 'hidden' }}>
        <div style={{
          position: 'absolute', top: '-40px', right: '-40px',
          width: 200, height: 200,
          borderRadius: '50%',
          background: 'rgba(255,255,255,0.08)',
          pointerEvents: 'none',
        }} />
        <Container className="text-center" style={{ position: 'relative' }}>
          <div style={{
            background: 'rgba(255,255,255,0.15)',
            borderRadius: '50%',
            width: 72,
            height: 72,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            margin: '0 auto 1.25rem',
          }}>
            <FaRocket size={32} />
          </div>
          <h2 className="mb-3 fw-bold">Ready to Transform Your Farming?</h2>
          <p className="lead mb-4" style={{ opacity: 0.88 }}>
            Join thousands of farmers already using Agri-Tech
          </p>
          <Button
            as={Link}
            to="/register"
            variant="light"
            size="lg"
            className="px-5 py-2 fw-bold rounded-pill"
            style={{ color: LIME.dark }}
          >
            Get Started Now <FaArrowRight className="ms-2" />
          </Button>
        </Container>
      </div>

      <Footer />

      <style>{`
        .fade-in-up { animation: fadeInUp 0.6s ease-out; }
        @keyframes fadeInUp {
          from { opacity: 0; transform: translateY(30px); }
          to   { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </>
  );
};

export default Home;
