import React, { useState, useEffect } from 'react';
import { Container, Row, Col, Card, Button, Form, Spinner, Modal } from 'react-bootstrap';
import {
  FaPlus, FaSearch, FaThumbsUp, FaComment, FaEye,
  FaUserCircle, FaCheckCircle, FaFire, FaClock,
  FaLeaf, FaPaperPlane
} from 'react-icons/fa';
import { getForumPosts, createPost, likePost, getPostById, addComment } from '../services/forumService';
import Navbar from '../components/Layout/Navbar';
import Footer from '../components/Layout/Footer';
import { useAuth } from '../context/AuthContext';
import { toast } from 'react-toastify';
import moment from 'moment';

const CATEGORIES = [
  { value: 'all',            label: 'All Topics',        icon: '🌐', color: '#607d8b' },
  { value: 'general',        label: 'General',           icon: '💬', color: '#65a30d' },
  { value: 'crops',          label: 'Crop Management',   icon: '🌾', color: '#84cc16' },
  { value: 'pests-diseases', label: 'Pests & Diseases',  icon: '🐛', color: '#f44336' },
  { value: 'irrigation',     label: 'Irrigation',        icon: '💧', color: '#2196f3' },
  { value: 'soil-health',    label: 'Soil Health',       icon: '🌱', color: '#795548' },
  { value: 'market',         label: 'Market & Pricing',  icon: '📈', color: '#ff9800' },
  { value: 'equipment',      label: 'Equipment & Tools', icon: '🔧', color: '#9c27b0' },
];

const getCatMeta = (value) =>
  CATEGORIES.find(c => c.value === value) || CATEGORIES[1];

const ForumPage = () => {
  const { user } = useAuth();
  const [posts, setPosts]                     = useState([]);
  const [loading, setLoading]                 = useState(true);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchTerm, setSearchTerm]           = useState('');
  const [sortBy, setSortBy]                   = useState('newest');
  const [formData, setFormData]               = useState({ title: '', content: '', category: 'general' });
  const [submitting, setSubmitting]           = useState(false);

  const [selectedPost, setSelectedPost]       = useState(null);
  const [postComments, setPostComments]       = useState([]);
  const [showPostModal, setShowPostModal]     = useState(false);
  const [loadingPost, setLoadingPost]         = useState(false);
  const [newComment, setNewComment]           = useState('');
  const [postingComment, setPostingComment]   = useState(false);

  useEffect(() => { fetchPosts(); }, [selectedCategory, searchTerm, sortBy]);

  const fetchPosts = async () => {
    setLoading(true);
    try {
      const filters = { category: selectedCategory };
      if (searchTerm) filters.search = searchTerm;
      if (sortBy === 'popular') filters.sort = 'popular';
      const data = await getForumPosts(filters);
      setPosts(data);
    } catch {
      toast.error('Failed to load forum posts');
    } finally {
      setLoading(false);
    }
  };

  const handleCreatePost = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      await createPost(formData);
      toast.success('Discussion posted!');
      setShowCreateModal(false);
      setFormData({ title: '', content: '', category: 'general' });
      fetchPosts();
    } catch {
      toast.error('Failed to create post');
    } finally {
      setSubmitting(false);
    }
  };

  const handleLike = async (e, postId) => {
    e.stopPropagation();
    try {
      await likePost(postId);
      fetchPosts();
    } catch {
      toast.error('Failed to like post');
    }
  };

  const handleViewPost = async (post) => {
    setSelectedPost(post);
    setShowPostModal(true);
    setLoadingPost(true);
    try {
      const data = await getPostById(post._id);
      setSelectedPost(data.post || post);
      setPostComments(data.comments || []);
    } catch {
      setPostComments([]);
    } finally {
      setLoadingPost(false);
    }
  };

  const handlePostComment = async (e) => {
    e.preventDefault();
    if (!newComment.trim()) return;
    setPostingComment(true);
    try {
      await addComment(selectedPost._id, newComment);
      toast.success('Comment posted!');
      setNewComment('');
      const data = await getPostById(selectedPost._id);
      setPostComments(data.comments || []);
    } catch {
      toast.error('Failed to post comment');
    } finally {
      setPostingComment(false);
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', minHeight: '100vh' }}>
      <Navbar />
      <Container fluid className="mt-4 px-4 pb-5" style={{ flex: 1 }}>

        {/* Page Header */}
        <div className="mb-4 p-4 rounded-4 fade-in" style={{
          background: 'linear-gradient(135deg, #fff 0%, #f7fee7 100%)',
          boxShadow: '0 2px 12px rgba(101,163,13,0.08)',
          borderLeft: '5px solid #84cc16',
        }}>
          <div className="d-flex justify-content-between align-items-center flex-wrap gap-3">
            <div>
              <h2 className="gradient-text mb-1" style={{ fontSize: '1.75rem', fontWeight: 700 }}>
                Community Forum
              </h2>
              <p className="text-muted mb-0" style={{ fontSize: '0.9rem' }}>
                Connect with farmers and agricultural experts &middot; {posts.length} discussions
              </p>
            </div>
            <Button
              variant="success"
              className="btn-gradient rounded-pill px-4"
              onClick={() => setShowCreateModal(true)}
            >
              <FaPlus className="me-2" /> New Discussion
            </Button>
          </div>
        </div>

        <Row className="g-4">
          {/* Sidebar */}
          <Col lg={3} xl={2}>
            <Card className="shadow-sm border-0 sticky-top" style={{ top: '80px', borderRadius: '16px' }}>
              <Card.Body className="p-3">
                <p className="text-muted mb-2" style={{
                  fontSize: '0.72rem', fontWeight: 600,
                  textTransform: 'uppercase', letterSpacing: '0.5px',
                }}>
                  Categories
                </p>
                {CATEGORIES.map(cat => (
                  <button
                    key={cat.value}
                    onClick={() => setSelectedCategory(cat.value)}
                    style={{
                      display: 'flex', alignItems: 'center', gap: '10px',
                      width: '100%', padding: '9px 12px', marginBottom: '3px',
                      border: 'none', borderRadius: '10px', cursor: 'pointer',
                      background: selectedCategory === cat.value ? '#f7fee7' : 'transparent',
                      color: selectedCategory === cat.value ? '#65a30d' : '#555',
                      fontWeight: selectedCategory === cat.value ? 600 : 400,
                      fontSize: '0.85rem',
                      transition: 'all 0.2s ease',
                      textAlign: 'left',
                    }}
                  >
                    <span style={{ fontSize: '15px', lineHeight: 1 }}>{cat.icon}</span>
                    <span>{cat.label}</span>
                    {selectedCategory === cat.value && (
                      <div style={{
                        marginLeft: 'auto', width: 6, height: 6,
                        borderRadius: '50%', background: '#84cc16',
                      }} />
                    )}
                  </button>
                ))}
              </Card.Body>
            </Card>
          </Col>

          {/* Main content */}
          <Col lg={9} xl={10}>
            {/* Search + Sort */}
            <div className="d-flex gap-3 mb-4 flex-wrap">
              <div style={{ position: 'relative', flex: 1, minWidth: '200px' }}>
                <FaSearch style={{
                  position: 'absolute', left: '14px', top: '50%',
                  transform: 'translateY(-50%)', color: '#9e9e9e', fontSize: '13px',
                }} />
                <input
                  type="text"
                  placeholder="Search discussions..."
                  value={searchTerm}
                  onChange={e => setSearchTerm(e.target.value)}
                  style={{
                    width: '100%', padding: '10px 12px 10px 38px',
                    border: '1.5px solid #e0e0e0', borderRadius: '10px',
                    fontSize: '0.875rem', outline: 'none',
                  }}
                  onFocus={e => {
                    e.target.style.borderColor = '#84cc16';
                    e.target.style.boxShadow = '0 0 0 3px rgba(132,204,22,0.12)';
                  }}
                  onBlur={e => {
                    e.target.style.borderColor = '#e0e0e0';
                    e.target.style.boxShadow = 'none';
                  }}
                />
              </div>
              <div className="d-flex gap-2">
                {[
                  { value: 'newest',  label: 'Newest',  icon: <FaClock size={12} /> },
                  { value: 'popular', label: 'Popular', icon: <FaFire  size={12} /> },
                ].map(opt => (
                  <button
                    key={opt.value}
                    onClick={() => setSortBy(opt.value)}
                    style={{
                      display: 'flex', alignItems: 'center', gap: '6px',
                      padding: '9px 16px',
                      border: `1.5px solid ${sortBy === opt.value ? '#84cc16' : '#e0e0e0'}`,
                      borderRadius: '10px', cursor: 'pointer', fontSize: '0.85rem',
                      background: sortBy === opt.value ? '#f7fee7' : 'white',
                      color: sortBy === opt.value ? '#65a30d' : '#666',
                      fontWeight: sortBy === opt.value ? 600 : 400,
                      transition: 'all 0.2s ease',
                    }}
                  >
                    {opt.icon} {opt.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Posts list */}
            {loading ? (
              <div className="d-flex flex-column align-items-center justify-content-center py-5 gap-3">
                <div style={{ position: 'relative', width: 48, height: 48 }}>
                  <div style={{
                    position: 'absolute', inset: 0, borderRadius: '50%',
                    border: '3px solid #ecfccb', borderTopColor: '#65a30d',
                    animation: 'spin 0.9s linear infinite',
                  }} />
                  <div style={{
                    position: 'absolute', inset: 0,
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                  }}>
                    <FaLeaf style={{ color: '#84cc16', fontSize: '16px' }} />
                  </div>
                </div>
                <p className="text-muted mb-0" style={{ fontSize: '0.875rem' }}>Loading discussions...</p>
              </div>
            ) : posts.length === 0 ? (
              <Card className="border-0 shadow-sm text-center py-5">
                <Card.Body>
                  <FaComment size={40} style={{ color: '#d9f99d', marginBottom: '12px' }} />
                  <h5 style={{ color: '#65a30d' }}>No discussions yet</h5>
                  <p className="text-muted mb-3">Be the first to start a conversation!</p>
                  <Button
                    variant="success"
                    className="btn-gradient rounded-pill px-4"
                    onClick={() => setShowCreateModal(true)}
                  >
                    <FaPlus className="me-2" /> Start Discussion
                  </Button>
                </Card.Body>
              </Card>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                {posts.map(post => {
                  const cat = getCatMeta(post.category);
                  return (
                    <Card
                      key={post._id}
                      className="border-0 shadow-sm card-hover"
                      style={{ cursor: 'pointer', borderRadius: '14px' }}
                      onClick={() => handleViewPost(post)}
                    >
                      <Card.Body className="p-4" style={{ display: 'flex', flexDirection: 'column' }}>
                        <div className="d-flex gap-3">
                          {/* Avatar */}
                          <div style={{
                            width: 42, height: 42, borderRadius: '50%', flexShrink: 0,
                            background: 'linear-gradient(135deg, #ecfccb, #d9f99d)',
                            display: 'flex', alignItems: 'center', justifyContent: 'center',
                          }}>
                            <FaUserCircle style={{ color: '#84cc16', fontSize: '22px' }} />
                          </div>

                          <div style={{ flex: 1, minWidth: 0 }}>
                            {/* Category + resolved + time */}
                            <div className="d-flex align-items-center gap-2 mb-1 flex-wrap">
                              <span style={{
                                background: `${cat.color}18`, color: cat.color,
                                borderRadius: '6px', padding: '2px 8px',
                                fontSize: '0.75rem', fontWeight: 600,
                              }}>
                                {cat.icon} {cat.label}
                              </span>
                              {post.isResolved && (
                                <span style={{
                                  background: '#e3f2fd', color: '#1565c0',
                                  borderRadius: '6px', padding: '2px 8px',
                                  fontSize: '0.75rem', fontWeight: 600,
                                }}>
                                  <FaCheckCircle className="me-1" size={10} />Resolved
                                </span>
                              )}
                              <span className="text-muted ms-auto" style={{ fontSize: '0.75rem', whiteSpace: 'nowrap' }}>
                                {moment(post.createdAt).fromNow()}
                              </span>
                            </div>

                            {/* Title */}
                            <h6 style={{ fontWeight: 600, marginBottom: '4px', color: '#3f6212', fontSize: '1rem' }}>
                              {post.title}
                            </h6>

                            {/* Excerpt */}
                            <p className="text-muted mb-2" style={{ fontSize: '0.85rem', lineHeight: 1.5 }}>
                              {post.content && post.content.length > 120
                                ? post.content.substring(0, 120) + '...'
                                : post.content}
                            </p>

                            {/* Stats row */}
                            <div className="d-flex align-items-center gap-3 flex-wrap mt-auto pt-2" style={{ borderTop: '1px solid #f5f5f5' }}>
                              <span style={{ fontSize: '0.8rem', color: '#666' }}>
                                by <strong>{post.user?.name || 'Farmer'}</strong>
                              </span>
                              <div className="d-flex gap-3 ms-auto">
                                <button
                                  onClick={e => handleLike(e, post._id)}
                                  style={{
                                    display: 'flex', alignItems: 'center', gap: '5px',
                                    background: 'none', border: 'none', cursor: 'pointer',
                                    color: '#84cc16', fontSize: '0.8rem', padding: 0,
                                  }}
                                >
                                  <FaThumbsUp size={12} /> {post.likes?.length || 0}
                                </button>
                                <span style={{ display: 'flex', alignItems: 'center', gap: '5px', color: '#888', fontSize: '0.8rem' }}>
                                  <FaComment size={12} /> {post.commentCount || 0}
                                </span>
                                <span style={{ display: 'flex', alignItems: 'center', gap: '5px', color: '#888', fontSize: '0.8rem' }}>
                                  <FaEye size={12} /> {post.views || 0}
                                </span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </Card.Body>
                    </Card>
                  );
                })}
              </div>
            )}
          </Col>
        </Row>

        {/* Create Post Modal */}
        <Modal show={showCreateModal} onHide={() => setShowCreateModal(false)} size="lg" centered>
          <Modal.Header closeButton style={{ background: 'linear-gradient(135deg, #65a30d, #84cc16)', color: 'white' }}>
            <Modal.Title style={{ fontWeight: 600 }}>
              <FaLeaf className="me-2" /> Start a New Discussion
            </Modal.Title>
          </Modal.Header>
          <Form onSubmit={handleCreatePost}>
            <Modal.Body className="p-4">
              <Form.Group className="mb-3">
                <Form.Label>Title <span style={{ color: '#f44336' }}>*</span></Form.Label>
                <Form.Control
                  type="text"
                  placeholder="What's your question or topic?"
                  value={formData.title}
                  onChange={e => setFormData({ ...formData, title: e.target.value })}
                  required
                />
              </Form.Group>
              <Form.Group className="mb-3">
                <Form.Label>Category</Form.Label>
                <Form.Select
                  value={formData.category}
                  onChange={e => setFormData({ ...formData, category: e.target.value })}
                >
                  {CATEGORIES.filter(c => c.value !== 'all').map(cat => (
                    <option key={cat.value} value={cat.value}>{cat.icon} {cat.label}</option>
                  ))}
                </Form.Select>
              </Form.Group>
              <Form.Group>
                <Form.Label>Content <span style={{ color: '#f44336' }}>*</span></Form.Label>
                <Form.Control
                  as="textarea"
                  rows={6}
                  placeholder="Describe your question or share your experience in detail..."
                  value={formData.content}
                  onChange={e => setFormData({ ...formData, content: e.target.value })}
                  required
                />
                <Form.Text className="text-muted">
                  {formData.content.length} / 2000 characters
                </Form.Text>
              </Form.Group>
            </Modal.Body>
            <Modal.Footer>
              <Button variant="light" onClick={() => setShowCreateModal(false)}>Cancel</Button>
              <Button type="submit" variant="success" className="btn-gradient px-4" disabled={submitting}>
                {submitting ? (
                  <>
                    <span style={{
                      width: 14, height: 14,
                      border: '2px solid rgba(255,255,255,0.4)',
                      borderTopColor: 'white', borderRadius: '50%',
                      animation: 'spin 0.8s linear infinite',
                      display: 'inline-block', marginRight: 8,
                    }} />
                    Posting...
                  </>
                ) : (
                  <><FaPaperPlane className="me-2" />Post Discussion</>
                )}
              </Button>
            </Modal.Footer>
          </Form>
        </Modal>

        {/* Post Detail Modal */}
        <Modal
          show={showPostModal}
          onHide={() => { setShowPostModal(false); setSelectedPost(null); setPostComments([]); }}
          size="lg"
          centered
        >
          {selectedPost && (
            <>
              <Modal.Header closeButton style={{ borderBottom: '1px solid #f0f0f0' }}>
                <div style={{ flex: 1, paddingRight: '1rem' }}>
                  <div className="d-flex align-items-center gap-2 mb-1 flex-wrap">
                    {(() => {
                      const cat = getCatMeta(selectedPost.category);
                      return (
                        <span style={{
                          background: `${cat.color}18`, color: cat.color,
                          borderRadius: '6px', padding: '2px 8px',
                          fontSize: '0.75rem', fontWeight: 600,
                        }}>
                          {cat.icon} {cat.label}
                        </span>
                      );
                    })()}
                    {selectedPost.isResolved && (
                      <span style={{
                        background: '#e3f2fd', color: '#1565c0',
                        borderRadius: '6px', padding: '2px 8px',
                        fontSize: '0.75rem', fontWeight: 600,
                      }}>
                        <FaCheckCircle className="me-1" size={10} />Resolved
                      </span>
                    )}
                  </div>
                  <Modal.Title style={{ fontSize: '1.1rem', fontWeight: 700, color: '#3f6212' }}>
                    {selectedPost.title}
                  </Modal.Title>
                  <small className="text-muted">
                    by <strong>{selectedPost.user?.name}</strong>
                    {' � '}{moment(selectedPost.createdAt).fromNow()}
                    {' � '}<FaEye size={11} className="me-1" />{selectedPost.views || 0} views
                  </small>
                </div>
              </Modal.Header>

              <Modal.Body className="p-0" style={{ maxHeight: '70vh', overflowY: 'auto' }}>
                {/* Post body */}
                <div className="p-4" style={{ borderBottom: '1px solid #f0f0f0' }}>
                  <p style={{ fontSize: '0.95rem', lineHeight: 1.75, color: '#333', whiteSpace: 'pre-wrap' }}>
                    {selectedPost.content}
                  </p>
                  <div className="d-flex align-items-center gap-3 mt-3">
                    <button
                      onClick={e => handleLike(e, selectedPost._id)}
                      style={{
                        display: 'flex', alignItems: 'center', gap: '6px',
                        background: '#f7fee7', border: '1.5px solid #d9f99d',
                        borderRadius: '8px', padding: '6px 14px', cursor: 'pointer',
                        color: '#65a30d', fontSize: '0.85rem', fontWeight: 500,
                        transition: 'all 0.2s ease',
                      }}
                    >
                      <FaThumbsUp size={13} /> {selectedPost.likes?.length || 0} Likes
                    </button>
                    <span style={{ color: '#888', fontSize: '0.85rem' }}>
                      <FaComment size={13} className="me-1" />
                      {postComments.length} comment{postComments.length !== 1 ? 's' : ''}
                    </span>
                  </div>
                </div>

                {/* Comments */}
                <div className="p-4">
                  <h6 style={{ fontWeight: 600, color: '#65a30d', marginBottom: '1rem' }}>
                    Comments ({postComments.length})
                  </h6>

                  {loadingPost ? (
                    <div className="text-center py-3">
                      <Spinner animation="border" variant="success" size="sm" />
                    </div>
                  ) : postComments.length === 0 ? (
                    <p className="text-center text-muted py-3 mb-0" style={{ fontSize: '0.875rem' }}>
                      No comments yet. Be the first to reply!
                    </p>
                  ) : (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', marginBottom: '1.5rem' }}>
                      {postComments.map(comment => (
                        <div
                          key={comment._id}
                          style={{
                            display: 'flex', gap: '12px',
                            padding: '12px 14px',
                            background: comment.isExpertAnswer ? '#f7fee7' : '#fafafa',
                            borderRadius: '12px',
                            border: comment.isExpertAnswer ? '1.5px solid #d9f99d' : '1px solid #f0f0f0',
                          }}
                        >
                          <div style={{
                            width: 34, height: 34, borderRadius: '50%', flexShrink: 0,
                            background: 'linear-gradient(135deg, #ecfccb, #d9f99d)',
                            display: 'flex', alignItems: 'center', justifyContent: 'center',
                          }}>
                            <FaUserCircle style={{ color: '#84cc16', fontSize: '18px' }} />
                          </div>
                          <div style={{ flex: 1 }}>
                            <div className="d-flex align-items-center gap-2 mb-1 flex-wrap">
                              <strong style={{ fontSize: '0.85rem', color: '#333' }}>
                                {comment.user?.name}
                              </strong>
                              {comment.user?.role === 'expert' && (
                                <span style={{
                                  background: '#e3f2fd', color: '#1565c0',
                                  borderRadius: '5px', padding: '1px 7px',
                                  fontSize: '0.7rem', fontWeight: 600,
                                }}>
                                  Expert
                                </span>
                              )}
                              {comment.isExpertAnswer && (
                                <span style={{
                                  background: '#ecfccb', color: '#65a30d',
                                  borderRadius: '5px', padding: '1px 7px',
                                  fontSize: '0.7rem', fontWeight: 600,
                                }}>
                                  <FaCheckCircle size={9} className="me-1" />Best Answer
                                </span>
                              )}
                              <span className="text-muted ms-auto" style={{ fontSize: '0.75rem' }}>
                                {moment(comment.createdAt).fromNow()}
                              </span>
                            </div>
                            <p style={{ fontSize: '0.875rem', color: '#444', marginBottom: 0, lineHeight: 1.6 }}>
                              {comment.content}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Reply box */}
                  <Form onSubmit={handlePostComment}>
                    <div style={{ display: 'flex', gap: '10px', alignItems: 'flex-end' }}>
                      <Form.Control
                        as="textarea"
                        rows={2}
                        placeholder="Write a reply..."
                        value={newComment}
                        onChange={e => setNewComment(e.target.value)}
                        style={{ resize: 'none', borderRadius: '12px', fontSize: '0.875rem' }}
                      />
                      <Button
                        type="submit"
                        variant="success"
                        className="btn-gradient"
                        disabled={postingComment || !newComment.trim()}
                        style={{ borderRadius: '12px', padding: '10px 16px', flexShrink: 0 }}
                      >
                        {postingComment
                          ? <Spinner size="sm" animation="border" />
                          : <FaPaperPlane size={14} />
                        }
                      </Button>
                    </div>
                  </Form>
                </div>
              </Modal.Body>
            </>
          )}
        </Modal>
      </Container>
      <Footer />

      <style>{`
        .gradient-text {
          background: linear-gradient(135deg, #65a30d, #84cc16);
          -webkit-background-clip: text;
          background-clip: text;
          color: transparent;
        }
        .gradient-bg  { background: linear-gradient(135deg, #65a30d, #84cc16); }
        .btn-gradient { background: linear-gradient(135deg, #65a30d, #84cc16); border: none; }
        .btn-gradient:hover { background: linear-gradient(135deg, #3f6212, #65a30d); color: white; }
        .card-hover { transition: transform 0.2s ease, box-shadow 0.2s ease; }
        .card-hover:hover { transform: translateY(-3px); box-shadow: 0 6px 20px rgba(0,0,0,0.09) !important; }
        @keyframes spin { to { transform: rotate(360deg); } }
      `}</style>
    </div>
  );
};

export default ForumPage;
