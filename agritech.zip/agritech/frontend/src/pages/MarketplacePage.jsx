import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Container, Row, Col, Card, Button, Form, InputGroup, Badge, Spinner, Modal, Alert } from 'react-bootstrap';
import { FaSearch, FaFilter, FaRupeeSign, FaStar, FaTruck, FaShieldAlt, FaShoppingCart, FaPlus, FaEdit, FaTrash, FaLeaf, FaImage, FaTimes } from 'react-icons/fa';
import { getAllProducts, addProductReview, createProduct, updateProduct, deleteProduct } from '../services/productService';
import { createBooking } from '../services/bookingService';
import Navbar from '../components/Layout/Navbar';
import Footer from '../components/Layout/Footer';
import { useAuth } from '../context/AuthContext';
import { toast } from 'react-toastify';

const MarketplacePage = () => {
  const { user, isAdmin } = useAuth();
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [debouncedSearchTerm, setDebouncedSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [showProductModal, setShowProductModal] = useState(false);
  const [showBookingModal, setShowBookingModal] = useState(false);
  const [showProductFormModal, setShowProductFormModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState(null);
  const [quantity, setQuantity] = useState(1);
  const [review, setReview] = useState({ rating: 5, comment: '' });
  const [imageUploading, setImageUploading] = useState(false);
  const [imagePreview, setImagePreview] = useState(null);
  const imageInputRef = useRef(null);
  const [productForm, setProductForm] = useState({
    name: '',
    category: 'seeds',
    description: '',
    price: '',
    unit: 'kg',
    stock: '',
    manufacturer: '',
    images: []
  });

  const categories = [
    { value: 'all', label: 'All Products' },
    { value: 'seeds', label: '🌱 Seeds' },
    { value: 'fertilizers', label: '💚 Fertilizers' },
    { value: 'pesticides', label: '🐛 Pesticides' },
    { value: 'herbicides', label: '🌿 Herbicides' },
    { value: 'equipment', label: '🚜 Equipment' },
    { value: 'tools', label: '🔧 Tools' }
  ];

  // Debounce search term to prevent too many API calls
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearchTerm(searchTerm);
    }, 500); // Wait 500ms after user stops typing

    return () => clearTimeout(timer);
  }, [searchTerm]);

  // Fetch products when search or category changes
  useEffect(() => {
    fetchProducts();
  }, [selectedCategory, debouncedSearchTerm]);

  const fetchProducts = async () => {
    setLoading(true);
    try {
      const filters = {};
      // Only send category if it's not 'all'
      if (selectedCategory && selectedCategory !== 'all') {
        filters.category = selectedCategory;
      }
      if (debouncedSearchTerm) filters.search = debouncedSearchTerm;
      const data = await getAllProducts(filters);
      setProducts(data);
    } catch (error) {
      console.error('Error fetching products:', error);
      toast.error('Failed to load products');
    } finally {
      setLoading(false);
    }
  };

  const handleBooking = async () => {
    try {
      const bookingData = {
        product: selectedProduct._id,
        bookingType: 'product_purchase',
        quantity,
        totalAmount: selectedProduct.price * quantity,
        deliveryAddress: user?.address || {}
      };
      await createBooking(bookingData);
      toast.success('Order placed successfully!');
      setShowBookingModal(false);
    } catch (error) {
      toast.error('Failed to place order');
    }
  };

  const handleReview = async (e) => {
    e.preventDefault();
    try {
      await addProductReview(selectedProduct._id, review);
      toast.success('Review added!');
      setReview({ rating: 5, comment: '' });
      fetchProducts();
    } catch (error) {
      toast.error('Failed to add review');
    }
  };

  // Admin functions for managing products
  const handleCreateProduct = async (e) => {
    e.preventDefault();
    try {
      await createProduct(productForm);
      toast.success('Product created successfully!');
      setShowProductFormModal(false);
      setImagePreview(null);
      setProductForm({
        name: '',
        category: 'seeds',
        description: '',
        price: '',
        unit: 'kg',
        stock: '',
        manufacturer: '',
        images: []
      });
      fetchProducts();
    } catch (error) {
      toast.error(error.response?.data?.message || 'Failed to create product');
    }
  };

  const handleUpdateProduct = async (e) => {
    e.preventDefault();
    try {
      await updateProduct(editingProduct._id, productForm);
      toast.success('Product updated successfully!');
      setShowProductFormModal(false);
      setEditingProduct(null);
      setImagePreview(null);
      setProductForm({
        name: '',
        category: 'seeds',
        description: '',
        price: '',
        unit: 'kg',
        stock: '',
        manufacturer: '',
        images: []
      });
      fetchProducts();
    } catch (error) {
      toast.error('Failed to update product');
    }
  };

  const handleDeleteProduct = async (id) => {
    if (window.confirm('Are you sure you want to delete this product?')) {
      try {
        await deleteProduct(id);
        toast.success('Product deleted successfully');
        fetchProducts();
      } catch (error) {
        toast.error('Failed to delete product');
      }
    }
  };

  const openProductForm = (product = null) => {
    if (product) {
      setEditingProduct(product);
      setProductForm({
        name: product.name,
        category: product.category,
        description: product.description,
        price: product.price,
        unit: product.unit,
        stock: product.stock,
        manufacturer: product.manufacturer || '',
        images: product.images || []
      });
      setImagePreview(
        product.images?.[0]
          ? (product.images[0].startsWith('/uploads/')
              ? `http://localhost:5000${product.images[0]}`
              : product.images[0])
          : null
      );
    } else {
      setEditingProduct(null);
      setProductForm({
        name: '',
        category: 'seeds',
        description: '',
        price: '',
        unit: 'kg',
        stock: '',
        manufacturer: '',
        images: []
      });
      setImagePreview(null);
    }
    setShowProductFormModal(true);
  };

  const handleImageUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    // Local preview immediately
    setImagePreview(URL.createObjectURL(file));

    const formData = new FormData();
    formData.append('image', file);
    setImageUploading(true);
    try {
      const res = await fetch('http://localhost:5000/api/upload/single', {
        method: 'POST',
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
        body: formData,
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message);
      setProductForm(prev => ({ ...prev, images: [data.url] }));
      toast.success('Image uploaded');
    } catch (err) {
      toast.error('Image upload failed: ' + err.message);
      setImagePreview(null);
    } finally {
      setImageUploading(false);
    }
  };

  const removeImage = () => {
    setImagePreview(null);
    setProductForm(prev => ({ ...prev, images: [] }));
    if (imageInputRef.current) imageInputRef.current.value = '';
  };

  if (loading) {
    return (
      <>
        <Navbar />
        <div className="d-flex flex-column justify-content-center align-items-center" style={{ minHeight: '70vh', gap: '1rem' }}>
          <div style={{ position: 'relative', width: 56, height: 56 }}>
            <div style={{ position: 'absolute', inset: 0, borderRadius: '50%', border: '3px solid #ecfccb', borderTopColor: '#65a30d', animation: 'spin 0.9s linear infinite' }} />
            <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <FaLeaf style={{ color: '#84cc16', fontSize: '20px' }} />
            </div>
          </div>
          <p className="text-muted mb-0" style={{ fontSize: '0.9rem' }}>Loading products...</p>
          <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
        </div>
      </>
    );
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', minHeight: '100vh' }}>
      <Navbar />
      <Container fluid className="mt-4 px-4 pb-5" style={{ flex: 1 }}>
        {/* Header */}
        <div className="mb-4 p-4 rounded-4 fade-in" style={{
          background: 'linear-gradient(135deg, #fff 0%, #f7fee7 100%)',
          boxShadow: '0 2px 12px rgba(101,163,13,0.08)',
          borderLeft: '5px solid #84cc16',
        }}>
          <div className="d-flex justify-content-between align-items-center flex-wrap gap-3">
            <div>
              <h2 className="gradient-text mb-1" style={{ fontSize: '1.75rem', fontWeight: 700 }}>
                 Agri-Marketplace
              </h2>
              <p className="text-muted mb-0" style={{ fontSize: '0.9rem' }}>
                Quality farming products at competitive prices
              </p>
            </div>
            {isAdmin && (
              <Button variant="success" onClick={() => openProductForm()} className="btn-gradient rounded-pill px-4">
                <FaPlus className="me-2" /> Add Product
              </Button>
            )}
          </div>
        </div>

        {/* Search and Filter */}
        <div className="d-flex gap-3 mb-4 flex-wrap align-items-center p-3 rounded-3" style={{ background: 'white', boxShadow: '0 2px 8px rgba(0,0,0,0.06)' }}>
          <div style={{ position: 'relative', flex: 1, minWidth: '200px' }}>
            <FaSearch style={{ position: 'absolute', left: '13px', top: '50%', transform: 'translateY(-50%)', color: '#9e9e9e', fontSize: '13px' }} />
            <input
              type="text"
              placeholder="Search products..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              style={{
                width: '100%', padding: '10px 12px 10px 36px',
                border: '1.5px solid #e0e0e0', borderRadius: '10px',
                fontSize: '0.875rem', outline: 'none',
              }}
              onFocus={e => { e.target.style.borderColor = '#84cc16'; e.target.style.boxShadow = '0 0 0 3px rgba(132,204,22,0.12)'; }}
              onBlur={e => { e.target.style.borderColor = '#e0e0e0'; e.target.style.boxShadow = 'none'; }}
            />
          </div>
          <Form.Select
            value={selectedCategory}
            onChange={e => setSelectedCategory(e.target.value)}
            style={{ maxWidth: '200px', borderRadius: '10px', border: '1.5px solid #e0e0e0', fontSize: '0.875rem' }}
          >
            {categories.map(cat => (
              <option key={cat.value} value={cat.value}>{cat.label}</option>
            ))}
          </Form.Select>
          <small className="text-muted ms-auto" style={{ whiteSpace: 'nowrap' }}>
            {products.length} product{products.length !== 1 ? 's' : ''} found
          </small>
        </div>

        {/* Products Grid */}
        {products.length === 0 ? (
          <Card className="text-center py-5 border-0 shadow-sm" style={{ borderRadius: '16px' }}>
            <Card.Body>
              <div style={{ fontSize: '48px', marginBottom: '12px' }}>🛒</div>
              <h5 style={{ color: '#65a30d' }}>No products found</h5>
              <p className="text-muted">Try a different search or category.</p>
            </Card.Body>
          </Card>
        ) : (
          <Row className="g-4">
            {products.map((product) => (
              <Col md={6} lg={4} xl={3} key={product._id}>
                <Card className="h-100 card-hover shadow-sm border-0" style={{ borderRadius: '16px', overflow: 'hidden' }}>
                  {/* Product image */}
                  <div style={{ position: 'relative', height: '180px', overflow: 'hidden', background: '#f5f5f5' }}>
                    <img
                      src={product.images?.[0]
                        ? (product.images[0].startsWith('/uploads/')
                            ? `http://localhost:5000${product.images[0]}`
                            : product.images[0])
                        : `https://via.placeholder.com/300x180/e8f5e9/2e7d32?text=${encodeURIComponent(product.name)}`}
                      alt={product.name}
                      style={{ width: '100%', height: '100%', objectFit: 'cover', transition: 'transform 0.3s ease' }}
                      onError={e => { e.target.src = `https://via.placeholder.com/300x180/e8f5e9/2e7d32?text=${encodeURIComponent(product.name)}`; }}
                    />
                    <div style={{ position: 'absolute', top: '10px', left: '10px' }}>
                      <span style={{
                        background: 'rgba(255,255,255,0.92)', color: '#65a30d',
                        borderRadius: '8px', padding: '3px 10px',
                        fontSize: '0.75rem', fontWeight: 600,
                        backdropFilter: 'blur(4px)',
                      }}>
                        {product.category}
                      </span>
                    </div>
                    {isAdmin && (
                      <div style={{ position: 'absolute', top: '8px', right: '8px', display: 'flex', gap: '4px' }}>
                        <button
                          onClick={() => openProductForm(product)}
                          style={{ background: 'white', border: 'none', borderRadius: '8px', padding: '5px 7px', cursor: 'pointer', color: '#65a30d', boxShadow: '0 2px 6px rgba(0,0,0,0.1)' }}
                        >
                          <FaEdit size={12} />
                        </button>
                        <button
                          onClick={() => handleDeleteProduct(product._id)}
                          style={{ background: 'white', border: 'none', borderRadius: '8px', padding: '5px 7px', cursor: 'pointer', color: '#f44336', boxShadow: '0 2px 6px rgba(0,0,0,0.1)' }}
                        >
                          <FaTrash size={12} />
                        </button>
                      </div>
                    )}
                  </div>

                  <Card.Body className="p-3">
                    <h6 className="mb-1" style={{ fontWeight: 600, color: '#3f6212', fontSize: '0.95rem' }}>
                      {product.name}
                    </h6>
                    <p className="text-muted mb-2" style={{ fontSize: '0.8rem', lineHeight: 1.4 }}>
                      {product.description?.length > 70 ? product.description.substring(0, 70) + '…' : product.description}
                    </p>
                    <div className="d-flex justify-content-between align-items-center mb-2">
                      <span style={{ fontWeight: 700, color: '#65a30d', fontSize: '1.05rem' }}>
                        ₱{product.price}<span style={{ fontSize: '0.75rem', fontWeight: 400, color: '#888' }}>/{product.unit}</span>
                      </span>
                      {product.rating > 0 && (
                        <span style={{ fontSize: '0.8rem', color: '#ff9800', fontWeight: 500 }}>
                          <FaStar size={11} className="me-1" />{product.rating.toFixed(1)}
                        </span>
                      )}
                    </div>
                    <div className="d-flex justify-content-between align-items-center mb-3">
                      <small className="text-muted" style={{ fontSize: '0.75rem' }}>
                        {product.stock > 0
                          ? <span style={{ color: '#84cc16' }}>✓ {product.stock} {product.unit}s in stock</span>
                          : <span style={{ color: '#f44336' }}>✗ Out of stock</span>
                        }
                      </small>
                    </div>
                    <Button
                      variant="outline-success"
                      size="sm"
                      className="w-100"
                      style={{ borderRadius: '10px', fontWeight: 500, fontSize: '0.85rem' }}
                      onClick={() => { setSelectedProduct(product); setShowProductModal(true); }}
                      disabled={product.stock === 0}
                    >
                      {product.stock === 0 ? 'Out of Stock' : 'View Details'}
                    </Button>
                  </Card.Body>
                </Card>
              </Col>
            ))}
          </Row>
        )}

        {/* Product Details Modal */}
        <Modal show={showProductModal} onHide={() => setShowProductModal(false)} size="lg">
          {selectedProduct && (
            <>
              <Modal.Header closeButton className="bg-white">
                <Modal.Title>{selectedProduct.name}</Modal.Title>
              </Modal.Header>
              <Modal.Body>
                <Row>
                  <Col md={5}>
                    <img 
                      src={selectedProduct.images?.[0]
                        ? (selectedProduct.images[0].startsWith('/uploads/')
                            ? `http://localhost:5000${selectedProduct.images[0]}`
                            : selectedProduct.images[0])
                        : 'https://via.placeholder.com/300x250/e8f5e9/2e7d32?text=No+Image'} 
                      alt={selectedProduct.name}
                      className="img-fluid rounded"
                      style={{ width: '100%', maxHeight: '250px', objectFit: 'cover' }}
                      onError={e => { e.target.src = 'https://via.placeholder.com/300x250/e8f5e9/2e7d32?text=No+Image'; }}
                    />
                  </Col>
                  <Col md={7}>
                    <Badge bg="success" className="mb-2">{selectedProduct.category}</Badge>
                    <h4 className="text-success mb-2">₱{selectedProduct.price}/{selectedProduct.unit}</h4>
                    <p className="small">{selectedProduct.description}</p>
                    <p><strong>Stock:</strong> {selectedProduct.stock} {selectedProduct.unit}s available</p>
                    <p><strong>Manufacturer:</strong> {selectedProduct.manufacturer || 'Standard'}</p>
                    <div className="mb-3">
                      <Form.Label>Quantity</Form.Label>
                      <Form.Control
                        type="number"
                        min="1"
                        max={selectedProduct.stock}
                        value={quantity}
                        onChange={(e) => setQuantity(parseInt(e.target.value))}
                        className="w-50"
                      />
                    </div>
                    <Button 
                      variant="success" 
                      className="w-100 mb-2"
                      onClick={() => setShowBookingModal(true)}
                      disabled={selectedProduct.stock === 0}
                    >
                      <FaShoppingCart className="me-2" /> Buy Now
                    </Button>
                    {selectedProduct.stock === 0 && (
                      <Alert variant="warning" className="small mt-2">Out of stock</Alert>
                    )}
                    <Alert variant="info" className="small mt-2">
                      <FaTruck className="me-2" /> Free shipping on orders above ₱1000
                    </Alert>
                  </Col>
                </Row>
                <hr />
                <h6>Customer Reviews</h6>
                <Form onSubmit={handleReview}>
                  <Form.Select 
                    className="mb-2 w-50" 
                    value={review.rating} 
                    onChange={(e) => setReview({ ...review, rating: parseInt(e.target.value) })}
                  >
                    <option value="5">★★★★★ Excellent</option>
                    <option value="4">★★★★ Good</option>
                    <option value="3">★★★ Average</option>
                    <option value="2">★★ Poor</option>
                    <option value="1">★ Terrible</option>
                  </Form.Select>
                  <Form.Control
                    as="textarea"
                    rows={2}
                    placeholder="Write your review..."
                    value={review.comment}
                    onChange={(e) => setReview({ ...review, comment: e.target.value })}
                    className="mb-2"
                  />
                  <Button type="submit" variant="outline-success" size="sm">Submit Review</Button>
                </Form>
                <div className="mt-3">
                  {selectedProduct.reviews?.length === 0 && (
                    <p className="text-muted small">No reviews yet. Be the first to review!</p>
                  )}
                  {selectedProduct.reviews?.slice().reverse().map((rev, idx) => (
                    <div key={idx} className="border-bottom pb-2 mb-2">
                      <div className="d-flex align-items-center gap-2">
                        <div className="text-warning">
                          {'★'.repeat(rev.rating)}{'☆'.repeat(5 - rev.rating)}
                        </div>
                        <small className="text-muted">- {rev.user?.name || 'Anonymous'}</small>
                      </div>
                      <p className="small mb-0 mt-1">{rev.comment}</p>
                      <small className="text-muted">{new Date(rev.date).toLocaleDateString()}</small>
                    </div>
                  ))}
                </div>
              </Modal.Body>
            </>
          )}
        </Modal>

        {/* Booking Modal */}
        <Modal show={showBookingModal} onHide={() => setShowBookingModal(false)}>
          <Modal.Header closeButton>
            <Modal.Title>Confirm Order</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <p><strong>Product:</strong> {selectedProduct?.name}</p>
            <p><strong>Quantity:</strong> {quantity} {selectedProduct?.unit}</p>
            <p><strong>Total:</strong> ₱{selectedProduct?.price * quantity}</p>
            <Alert variant="success" className="mt-3">
              <FaShieldAlt className="me-2" /> Secure payment after delivery
            </Alert>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={() => setShowBookingModal(false)}>Cancel</Button>
            <Button variant="success" onClick={handleBooking}>Place Order</Button>
          </Modal.Footer>
        </Modal>

        {/* Admin Product Form Modal */}
        <Modal show={showProductFormModal} onHide={() => { setShowProductFormModal(false); setImagePreview(null); }} size="lg">
          <Modal.Header closeButton className="gradient-bg text-white">
            <Modal.Title>
              {editingProduct ? '✏️ Edit Product' : '➕ Add New Product'}
            </Modal.Title>
          </Modal.Header>
          <Form onSubmit={editingProduct ? handleUpdateProduct : handleCreateProduct}>
            <Modal.Body>
              <Form.Group className="mb-3">
                <Form.Label>Product Name *</Form.Label>
                <Form.Control
                  type="text"
                  value={productForm.name}
                  onChange={(e) => setProductForm({ ...productForm, name: e.target.value })}
                  required
                />
              </Form.Group>

              <Row>
                <Col md={6}>
                  <Form.Group className="mb-3">
                    <Form.Label>Category *</Form.Label>
                    <Form.Select
                      value={productForm.category}
                      onChange={(e) => setProductForm({ ...productForm, category: e.target.value })}
                      required
                    >
                      <option value="seeds">🌱 Seeds</option>
                      <option value="fertilizers">💚 Fertilizers</option>
                      <option value="pesticides">🐛 Pesticides</option>
                      <option value="herbicides">🌿 Herbicides</option>
                      <option value="equipment">🚜 Equipment</option>
                      <option value="tools">🔧 Tools</option>
                    </Form.Select>
                  </Form.Group>
                </Col>
                <Col md={6}>
                  <Form.Group className="mb-3">
                    <Form.Label>Unit</Form.Label>
                    <Form.Select
                      value={productForm.unit}
                      onChange={(e) => setProductForm({ ...productForm, unit: e.target.value })}
                    >
                      <option value="kg">Kilogram (kg)</option>
                      <option value="g">Gram (g)</option>
                      <option value="liter">Liter (L)</option>
                      <option value="ml">Milliliter (ml)</option>
                      <option value="piece">Piece</option>
                    </Form.Select>
                  </Form.Group>
                </Col>
              </Row>

              <Row>
                <Col md={6}>
                  <Form.Group className="mb-3">
                    <Form.Label>Price (₱) *</Form.Label>
                    <Form.Control
                      type="number"
                      step="0.01"
                      value={productForm.price}
                      onChange={(e) => setProductForm({ ...productForm, price: e.target.value })}
                      required
                    />
                  </Form.Group>
                </Col>
                <Col md={6}>
                  <Form.Group className="mb-3">
                    <Form.Label>Stock *</Form.Label>
                    <Form.Control
                      type="number"
                      value={productForm.stock}
                      onChange={(e) => setProductForm({ ...productForm, stock: e.target.value })}
                      required
                    />
                  </Form.Group>
                </Col>
              </Row>

              <Form.Group className="mb-3">
                <Form.Label>Description</Form.Label>
                <Form.Control
                  as="textarea"
                  rows={3}
                  value={productForm.description}
                  onChange={(e) => setProductForm({ ...productForm, description: e.target.value })}
                  placeholder="Product description..."
                />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label>Product Image</Form.Label>

                {/* Preview */}
                {imagePreview ? (
                  <div style={{ position: 'relative', display: 'inline-block', marginBottom: '10px' }}>
                    <img
                      src={imagePreview}
                      alt="Preview"
                      style={{ width: '100%', maxHeight: '180px', objectFit: 'cover', borderRadius: '10px', border: '1.5px solid #e0e0e0' }}
                    />
                    <button
                      type="button"
                      onClick={removeImage}
                      style={{
                        position: 'absolute', top: 6, right: 6,
                        background: '#f44336', border: 'none', borderRadius: '50%',
                        width: 26, height: 26, cursor: 'pointer',
                        display: 'flex', alignItems: 'center', justifyContent: 'center',
                        color: 'white', fontSize: 12,
                      }}
                    >
                      <FaTimes />
                    </button>
                    {imageUploading && (
                      <div style={{
                        position: 'absolute', inset: 0, background: 'rgba(255,255,255,0.7)',
                        display: 'flex', alignItems: 'center', justifyContent: 'center',
                        borderRadius: '10px',
                      }}>
                        <Spinner animation="border" variant="success" size="sm" />
                        <span style={{ marginLeft: 8, fontSize: '0.8rem', color: '#65a30d' }}>Uploading...</span>
                      </div>
                    )}
                  </div>
                ) : (
                  <div
                    onClick={() => imageInputRef.current?.click()}
                    style={{
                      border: '2px dashed #d0e8a8', borderRadius: '10px',
                      padding: '28px', textAlign: 'center', cursor: 'pointer',
                      background: '#f7fee7', marginBottom: '10px',
                      transition: 'border-color 0.2s',
                    }}
                    onMouseEnter={e => e.currentTarget.style.borderColor = '#84cc16'}
                    onMouseLeave={e => e.currentTarget.style.borderColor = '#d0e8a8'}
                  >
                    <FaImage style={{ fontSize: 28, color: '#84cc16', marginBottom: 8 }} />
                    <p style={{ margin: 0, fontSize: '0.85rem', color: '#65a30d', fontWeight: 500 }}>Click to upload image</p>
                    <p style={{ margin: 0, fontSize: '0.75rem', color: '#999' }}>JPG, PNG, WebP — max 5MB</p>
                  </div>
                )}

                <input
                  ref={imageInputRef}
                  type="file"
                  accept="image/jpeg,image/png,image/webp,image/gif"
                  style={{ display: 'none' }}
                  onChange={handleImageUpload}
                />

                {!imagePreview && (
                  <Button
                    type="button"
                    variant="outline-success"
                    size="sm"
                    onClick={() => imageInputRef.current?.click()}
                    disabled={imageUploading}
                    style={{ borderRadius: '8px' }}
                  >
                    <FaImage className="me-1" /> Choose Image
                  </Button>
                )}
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label>Manufacturer</Form.Label>
                <Form.Control
                  type="text"
                  value={productForm.manufacturer}
                  onChange={(e) => setProductForm({ ...productForm, manufacturer: e.target.value })}
                  placeholder="Manufacturer name"
                />
              </Form.Group>
            </Modal.Body>
            <Modal.Footer>
              <Button variant="secondary" onClick={() => setShowProductFormModal(false)}>Cancel</Button>
              <Button type="submit" variant="success">
                {editingProduct ? 'Update Product' : 'Create Product'}
              </Button>
            </Modal.Footer>
          </Form>
        </Modal>
      </Container>
      <Footer />

      <style>{`
        .gradient-text {
          background: linear-gradient(135deg, #65a30d, #84cc16);
          -webkit-background-clip: text;
          background-clip: text;
          color: transparent;
        }
        .gradient-bg {
          background: linear-gradient(135deg, #65a30d, #84cc16);
        }
        .btn-gradient {
          background: linear-gradient(135deg, #65a30d, #84cc16);
          border: none;
        }
        .card-hover {
          transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .card-hover:hover {
          transform: translateY(-5px);
          box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }
        @keyframes spin { to { transform: rotate(360deg); } }
      `}</style>
    </div>
  );
};

export default MarketplacePage;