import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Container, Row, Col, Card, Button } from 'react-bootstrap';
import {
  FaTractor, FaSeedling, FaChartLine, FaLeaf, FaComments,
  FaStore, FaArrowRight, FaCheckCircle, FaExclamationTriangle,
  FaCalendarAlt, FaPlus, FaTasks, FaBell, FaRocket,
} from 'react-icons/fa';
import Navbar from '../components/Layout/Navbar';
import Footer from '../components/Layout/Footer';
import { useAuth } from '../context/AuthContext';
import axios from 'axios';
import WeatherWidget from '../components/Dashboard/WeatherWidget';

const LIME = {
  dark:    '#3f6212',
  mid:     '#4d7c0f',
  base:    '#65a30d',
  light:   '#84cc16',
  bright:  '#a3e635',
  pale:    '#bef264',
  accent:  '#d9f99d',
  xlight:  '#ecfccb',
  xxlight: '#f7fee7',
};

const FarmerDashboard = () => {
  const navigate = useNavigate();
  const { user, isAuthenticated } = useAuth();
  const [stats, setStats] = useState({ farms: 0, crops: 0, activeCrops: 0, alerts: 0 });
  const [loading, setLoading] = useState(true);
  const [recentCrops, setRecentCrops] = useState([]);
  const [recentAlerts, setRecentAlerts] = useState([]);

  const getAuthHeaders = () => ({
    headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
  });

  useEffect(() => {
    if (!isAuthenticated) { navigate('/login'); return; }
    fetchDashboardData();
  }, [isAuthenticated, navigate]);

  const fetchDashboardData = async () => {
    setLoading(true);
    try {
      const [farmsRes, cropsRes] = await Promise.all([
        axios.get('http://localhost:5000/api/farms', getAuthHeaders()),
        axios.get('http://localhost:5000/api/crops', getAuthHeaders()),
      ]);
      const farms = farmsRes.data || [];
      const crops = cropsRes.data || [];
      const activeCrops = crops.filter(c => c.growthStage !== 'harvesting' && c.growthStage !== 'fallow').length;
      const allAlerts = crops.flatMap(crop =>
        (crop.alerts || []).map(alert => ({ ...alert, cropName: crop.name }))
      ).slice(0, 3);
      setStats({ farms: farms.length, crops: crops.length, activeCrops, alerts: allAlerts.length });
      setRecentCrops(crops.slice(0, 4));
      setRecentAlerts(allAlerts);
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const statCards = [
    { icon: <FaTractor size={26} />,            title: 'Total Farms',   value: stats.farms,       link: '/farms', bg: LIME.xlight,  color: LIME.dark },
    { icon: <FaSeedling size={26} />,           title: 'Total Crops',   value: stats.crops,       link: '/crops', bg: LIME.xlight,  color: LIME.mid },
    { icon: <FaLeaf size={26} />,               title: 'Active Crops',  value: stats.activeCrops, link: '/crops', bg: LIME.xlight,  color: LIME.base },
    { icon: <FaExclamationTriangle size={26} />, title: 'Active Alerts', value: stats.alerts,      link: '/crops', bg: '#fef3c7',    color: '#d97706' },
  ];

  const quickActions = [
    { name: 'Add Farm',    icon: <FaTractor />,  link: '/farms',       color: LIME.dark,  bg: LIME.xlight },
    { name: 'Add Crop',    icon: <FaSeedling />, link: '/crops',       color: LIME.mid,   bg: LIME.xlight },
    { name: 'Visit Forum', icon: <FaComments />, link: '/forum',       color: '#7c3aed',  bg: '#ede9fe' },
    { name: 'Marketplace', icon: <FaStore />,    link: '/marketplace', color: '#d97706',  bg: '#fef3c7' },
  ];

  if (loading) {
    return (
      <>
        <Navbar />
        <div className="d-flex flex-column justify-content-center align-items-center" style={{ minHeight: '70vh', gap: '1rem' }}>
          <div style={{ position: 'relative', width: 56, height: 56 }}>
            <div style={{
              position: 'absolute', inset: 0, borderRadius: '50%',
              border: `3px solid ${LIME.xlight}`,
              borderTopColor: LIME.base,
              animation: 'spin 0.9s linear infinite',
            }} />
            <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <FaLeaf style={{ color: LIME.light, fontSize: '20px' }} />
            </div>
          </div>
          <p className="text-muted mb-0" style={{ fontSize: '0.9rem' }}>Loading dashboard...</p>
          <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
        </div>
      </>
    );
  }

  return (
    <>
      <Navbar />
      <Container fluid className="mt-4 px-4 pb-2">

        {/* ── Welcome Banner ── */}
        <div className="mb-4 p-4 rounded-4 fade-in" style={{
          background: `linear-gradient(135deg, white 0%, ${LIME.xxlight} 100%)`,
          boxShadow: `0 2px 16px rgba(101,163,13,0.1)`,
          borderLeft: `5px solid ${LIME.light}`,
        }}>
          <div className="d-flex justify-content-between align-items-center flex-wrap gap-3">
            <div>
              <h2 className="gradient-text mb-1" style={{ fontSize: '1.75rem', fontWeight: 800 }}>
                Welcome back, {user?.name?.split(' ')[0] || 'Farmer'}! 🌿
              </h2>
              <p className="text-muted mb-0" style={{ fontSize: '0.9rem' }}>
                Here's what's happening with your farm today
              </p>
            </div>
            <div className="d-flex gap-2">
              <Button as={Link} to="/farms" variant="outline-success" className="rounded-pill" size="sm">
                <FaTractor className="me-2" /> Manage Farms
              </Button>
              <Button as={Link} to="/crops" className="rounded-pill btn-gradient" size="sm">
                <FaPlus className="me-2" /> Add Crop
              </Button>
            </div>
          </div>
        </div>

        {/* ── Stat Cards ── */}
        <Row className="g-3 mb-4">
          {statCards.map((card, idx) => (
            <Col md={3} sm={6} key={idx}>
              <Card
                className="border-0 shadow-sm h-100 card-hover"
                style={{ cursor: 'pointer', borderRadius: '18px', overflow: 'hidden' }}
                onClick={() => navigate(card.link)}
              >
                <div style={{ height: 3, background: `linear-gradient(90deg, ${card.color}, ${LIME.pale})` }} />
                <Card.Body className="p-3">
                  <div className="d-flex justify-content-between align-items-start">
                    <div>
                      <div className="mb-2 p-2 rounded-3 d-inline-flex" style={{ backgroundColor: card.bg }}>
                        <div style={{ color: card.color }}>{card.icon}</div>
                      </div>
                      <p className="text-muted mb-1" style={{ fontSize: '0.78rem', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.4px' }}>
                        {card.title}
                      </p>
                      <h3 className="mb-0 fw-bold" style={{ color: card.color, fontSize: '2rem' }}>{card.value}</h3>
                    </div>
                    <div style={{
                      background: card.bg, borderRadius: '8px', padding: '6px 8px',
                      display: 'flex', alignItems: 'center',
                    }}>
                      <FaArrowRight style={{ color: card.color, fontSize: '12px' }} />
                    </div>
                  </div>
                </Card.Body>
              </Card>
            </Col>
          ))}
        </Row>

        {/* ── Quick Actions + Alerts ── */}
        <Row className="g-4 mb-4">
          {/* Quick Actions */}
          <Col lg={6}>
            <Card className="border-0 shadow-sm h-100" style={{
              borderRadius: '18px',
              background: `linear-gradient(135deg, ${LIME.xxlight} 0%, ${LIME.xlight} 100%)`,
            }}>
              <Card.Header className="border-0 pt-4 pb-2" style={{ background: 'transparent' }}>
                <div className="d-flex align-items-center gap-2">
                  <div className="p-2 rounded-circle" style={{ backgroundColor: LIME.accent }}>
                    <FaTasks style={{ color: LIME.dark, fontSize: '16px' }} />
                  </div>
                  <h5 className="mb-0 fw-bold" style={{ color: LIME.dark }}>Quick Actions</h5>
                </div>
              </Card.Header>
              <Card.Body>
                <Row className="g-3">
                  {quickActions.map((action, idx) => (
                    <Col sm={6} key={idx}>
                      <Button
                        as={Link}
                        to={action.link}
                        variant="light"
                        className="w-100 py-3 border-0 rounded-3"
                        style={{
                          backgroundColor: action.bg,
                          transition: 'all 0.25s ease',
                          border: `1px solid transparent`,
                        }}
                        onMouseEnter={e => { e.currentTarget.style.transform = 'translateY(-3px)'; e.currentTarget.style.boxShadow = '0 6px 16px rgba(0,0,0,0.1)'; }}
                        onMouseLeave={e => { e.currentTarget.style.transform = 'translateY(0)'; e.currentTarget.style.boxShadow = 'none'; }}
                      >
                        <div style={{ color: action.color, fontSize: '22px' }} className="mb-2">{action.icon}</div>
                        <small className="fw-bold d-block" style={{ color: action.color }}>{action.name}</small>
                      </Button>
                    </Col>
                  ))}
                </Row>
              </Card.Body>
            </Card>
          </Col>

          {/* Recent Alerts */}
          <Col lg={6}>
            <Card className="border-0 shadow-sm h-100" style={{
              borderRadius: '18px',
              background: 'linear-gradient(135deg, #fffbeb 0%, #fef3c7 100%)',
            }}>
              <Card.Header className="border-0 pt-4 pb-2" style={{ background: 'transparent' }}>
                <div className="d-flex align-items-center gap-2">
                  <div className="p-2 rounded-circle" style={{ backgroundColor: '#fde68a' }}>
                    <FaBell style={{ color: '#d97706', fontSize: '16px' }} />
                  </div>
                  <h5 className="mb-0 fw-bold" style={{ color: '#92400e' }}>Recent Alerts</h5>
                </div>
              </Card.Header>
              <Card.Body>
                {recentAlerts.length === 0 ? (
                  <div className="text-center py-4">
                    <div style={{
                      width: 56, height: 56, borderRadius: '50%',
                      background: LIME.xlight,
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      margin: '0 auto 0.75rem',
                    }}>
                      <FaCheckCircle size={24} style={{ color: LIME.base }} />
                    </div>
                    <p className="text-muted mb-0 small">No new alerts. Your crops are doing well!</p>
                  </div>
                ) : (
                  recentAlerts.map((alert, idx) => (
                    <div key={idx} className="d-flex align-items-start gap-2 mb-3 p-3 rounded-3" style={{
                      backgroundColor: '#ffffff',
                      borderLeft: '4px solid #f59e0b',
                    }}>
                      <FaExclamationTriangle style={{ color: '#f59e0b', fontSize: '15px', marginTop: '2px' }} />
                      <div>
                        <div className="small fw-bold" style={{ color: '#92400e' }}>{alert.cropName}</div>
                        <div className="small text-muted">{alert.message || alert.type}</div>
                        <small className="text-muted">
                          {alert.date ? new Date(alert.date).toLocaleDateString() : 'Recently'}
                        </small>
                      </div>
                    </div>
                  ))
                )}
                {stats.alerts > 0 && (
                  <Button variant="link" size="sm" className="p-0 mt-2" as={Link} to="/crops" style={{ color: '#d97706' }}>
                    View all alerts <FaArrowRight className="ms-1" />
                  </Button>
                )}
              </Card.Body>
            </Card>
          </Col>
        </Row>

        {/* ── Weather Widget ── */}
        <Row className="g-4 mb-4">
          <Col lg={12}>
            <WeatherWidget />
          </Col>
        </Row>

        {/* ── Recent Crops ── */}
        <Row className="mt-2">
          <Col lg={12}>
            <Card className="border-0 shadow-sm" style={{ borderRadius: '18px', overflow: 'hidden' }}>
              <div style={{ height: 3, background: `linear-gradient(90deg, ${LIME.dark}, ${LIME.light})` }} />
              <Card.Header className="bg-white border-0 pt-4 pb-2 d-flex justify-content-between align-items-center">
                <div className="d-flex align-items-center gap-2">
                  <div className="p-2 rounded-circle d-inline-flex" style={{ backgroundColor: LIME.xlight }}>
                    <FaSeedling style={{ color: LIME.base, fontSize: '15px' }} />
                  </div>
                  <h5 className="mb-0 fw-bold" style={{ color: LIME.dark }}>🌱 Recent Crops</h5>
                </div>
                <Button as={Link} to="/crops" variant="link" size="sm" style={{ color: LIME.base }}>
                  View All <FaArrowRight className="ms-1" />
                </Button>
              </Card.Header>
              <Card.Body>
                {recentCrops.length === 0 ? (
                  <div className="text-center py-4">
                    <FaSeedling size={40} className="text-muted mb-2" />
                    <p className="text-muted mb-0">No crops added yet.</p>
                    <Button as={Link} to="/crops" className="mt-3 btn-gradient rounded-pill" size="sm">
                      <FaPlus className="me-2" /> Add Your First Crop
                    </Button>
                  </div>
                ) : (
                  <Row className="g-3">
                    {recentCrops.map((crop) => (
                      <Col md={6} lg={3} key={crop._id}>
                        <div style={{
                          background: `linear-gradient(135deg, ${LIME.xxlight}, white)`,
                          borderRadius: '14px',
                          padding: '1rem',
                          border: `1px solid ${LIME.accent}`,
                          transition: 'all 0.2s ease',
                        }}
                          onMouseEnter={e => { e.currentTarget.style.transform = 'translateY(-3px)'; e.currentTarget.style.boxShadow = `0 6px 20px rgba(101,163,13,0.15)`; }}
                          onMouseLeave={e => { e.currentTarget.style.transform = 'translateY(0)'; e.currentTarget.style.boxShadow = 'none'; }}
                        >
                          <div className="d-flex align-items-center gap-2 mb-2">
                            <div style={{ background: LIME.xlight, borderRadius: '8px', padding: '5px 7px' }}>
                              <FaSeedling style={{ color: LIME.base, fontSize: '13px' }} />
                            </div>
                            <strong style={{ color: LIME.dark, fontSize: '0.9rem' }}>{crop.name}</strong>
                          </div>
                          <div className="small text-muted">
                            <div>Stage: <span className="text-capitalize fw-medium">{crop.growthStage}</span></div>
                            <div>Health: <span style={{
                              color: crop.health === 'good' ? LIME.base : crop.health === 'excellent' ? LIME.dark : '#d97706',
                              fontWeight: 600,
                            }}>{crop.health}</span></div>
                            <div>Planted: {new Date(crop.plantingDate).toLocaleDateString()}</div>
                          </div>
                        </div>
                      </Col>
                    ))}
                  </Row>
                )}
              </Card.Body>
            </Card>
          </Col>
        </Row>

        {/* ── Tip Banner ── */}
        <Row className="mt-4 mb-4">
          <Col lg={12}>
            <div className="gradient-bg text-white rounded-4 p-4" style={{ position: 'relative', overflow: 'hidden' }}>
              <div style={{
                position: 'absolute', top: '-30px', right: '-30px',
                width: 140, height: 140, borderRadius: '50%',
                background: 'rgba(255,255,255,0.08)',
                pointerEvents: 'none',
              }} />
              <div className="d-flex justify-content-between align-items-center flex-wrap gap-3" style={{ position: 'relative' }}>
                <div className="d-flex align-items-center gap-3">
                  <div style={{
                    background: 'rgba(255,255,255,0.18)',
                    borderRadius: '12px',
                    padding: '10px',
                    display: 'flex',
                  }}>
                    <FaRocket size={24} />
                  </div>
                  <div>
                    <h5 className="mb-1 fw-bold">Farming Tip of the Day</h5>
                    <p className="mb-0 small" style={{ opacity: 0.88 }}>
                      Regular soil testing helps optimize fertilizer usage and improve crop yields.
                    </p>
                  </div>
                </div>
                <Button as={Link} to="/forum" variant="light" size="sm" className="rounded-pill fw-bold" style={{ color: LIME.dark }}>
                  <FaComments className="me-2" /> Discuss with Experts
                </Button>
              </div>
            </div>
          </Col>
        </Row>
      </Container>
      <Footer />

      <style>{`
        .gradient-text {
          background: linear-gradient(135deg, #3f6212, #84cc16);
          -webkit-background-clip: text;
          background-clip: text;
          color: transparent;
        }
        .gradient-bg {
          background: linear-gradient(135deg, #3f6212, #84cc16);
        }
        .btn-gradient {
          background: linear-gradient(135deg, #3f6212, #84cc16);
          border: none;
          color: white;
        }
        .btn-gradient:hover {
          background: linear-gradient(135deg, #1a2e05, #65a30d);
          color: white;
        }
        @keyframes spin { to { transform: rotate(360deg); } }
        .fade-in { animation: fadeIn 0.4s ease-out; }
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
      `}</style>
    </>
  );
};

export default FarmerDashboard;
