import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { 
  Container, Row, Col, Card, Button, Modal, Form, 
  Spinner, Badge, ProgressBar, Alert
} from 'react-bootstrap';
import { 
  FaPlus, FaEdit, FaTrash, FaSeedling, FaTint, 
  FaBug, FaCalendarAlt, FaChartLine, FaLeaf, 
  FaExclamationTriangle, FaCheckCircle, FaClock,
  FaThermometerHalf, FaHeartbeat, FaWater, FaTree,
  FaInfoCircle, FaTag, FaWeightHanging, FaRuler,
  FaPaperPlane
} from 'react-icons/fa';
import { toast } from 'react-toastify';
import axios from 'axios';
import Navbar from '../components/Layout/Navbar';
import Footer from '../components/Layout/Footer';
import { useAuth } from '../context/AuthContext';

const CropsPage = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useAuth();
  const [crops, setCrops] = useState([]);
  const [farms, setFarms] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [showIssueModal, setShowIssueModal] = useState(false);
  const [submittingIssue, setSubmittingIssue] = useState(false);
  const [editingCrop, setEditingCrop] = useState(null);
  const [selectedCrop, setSelectedCrop] = useState(null);
  const [issueData, setIssueData] = useState({ 
    type: 'pest', 
    description: '', 
    severity: 'medium' 
  });
  
  const [formData, setFormData] = useState({
    name: '',
    farm: '',
    variety: '',
    plantingDate: '',
    expectedHarvestDate: '',
    areaPlanted: { value: '', unit: 'acre' },
    growthStage: 'planting'
  });

  const getAuthHeaders = () => ({
    headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);
    try {
      const queryParams = new URLSearchParams(location.search);
      const farmId = queryParams.get('farm');
      
      const [cropsRes, farmsRes] = await Promise.all([
        axios.get('http://localhost:5000/api/crops', getAuthHeaders()),
        axios.get('http://localhost:5000/api/farms', getAuthHeaders())
      ]);
      
      let cropsData = cropsRes.data;
      if (farmId) {
        cropsData = cropsData.filter(crop => crop.farm?._id === farmId || crop.farm === farmId);
      }
      
      setCrops(cropsData);
      setFarms(farmsRes.data);
    } catch (error) {
      console.error('Error fetching data:', error);
      toast.error('Failed to load crops');
    } finally {
      setLoading(false);
    }
  };

  const handleOpenModal = (crop = null) => {
    if (crop) {
      setEditingCrop(crop);
      setFormData({
        name: crop.name,
        farm: crop.farm?._id || crop.farm,
        variety: crop.variety || '',
        plantingDate: crop.plantingDate?.split('T')[0] || '',
        expectedHarvestDate: crop.expectedHarvestDate?.split('T')[0] || '',
        areaPlanted: crop.areaPlanted || { value: '', unit: 'acre' },
        growthStage: crop.growthStage
      });
    } else {
      setEditingCrop(null);
      setFormData({
        name: '',
        farm: '',
        variety: '',
        plantingDate: '',
        expectedHarvestDate: '',
        areaPlanted: { value: '', unit: 'acre' },
        growthStage: 'planting'
      });
    }
    setShowModal(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editingCrop) {
        await axios.put(`http://localhost:5000/api/crops/${editingCrop._id}`, formData, getAuthHeaders());
        toast.success('Crop updated successfully!');
      } else {
        await axios.post('http://localhost:5000/api/crops', formData, getAuthHeaders());
        toast.success('Crop added successfully!');
      }
      setShowModal(false);
      fetchData();
    } catch (error) {
      toast.error(error.response?.data?.message || 'Operation failed');
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this crop?')) {
      try {
        await axios.delete(`http://localhost:5000/api/crops/${id}`, getAuthHeaders());
        toast.success('Crop deleted successfully');
        fetchData();
      } catch (error) {
        toast.error('Failed to delete crop');
      }
    }
  };

  const handleStageChange = async (cropId, newStage) => {
    try {
      await axios.put(`http://localhost:5000/api/crops/${cropId}/growth-stage`, 
        { growthStage: newStage }, 
        getAuthHeaders()
      );
      toast.success(`Growth stage updated to ${newStage}`);
      fetchData();
    } catch (error) {
      toast.error('Failed to update stage');
    }
  };

  const handleReportIssue = async (e) => {
  e.preventDefault();
  
  if (!issueData.description.trim()) {
    toast.error('Please provide a description of the issue');
    return;
  }
  
  setSubmittingIssue(true);
  
  try {
    // Make sure data is sent as strings, not objects
    const reportData = {
      type: issueData.type,        // Should be string: 'pest', 'disease', etc.
      issue: issueData.description, // Should be string
      severity: issueData.severity  // Should be string: 'low', 'medium', 'high'
    };
    
    console.log('Sending report data:', reportData);
    
    const response = await axios.post(
      `http://localhost:5000/api/crops/${selectedCrop._id}/report-issue`, 
      reportData,
      {
        headers: { 
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
          'Content-Type': 'application/json'
        }
      }
    );
    
    console.log('Report response:', response.data);
    
    toast.success(`Issue reported successfully! Our experts will review it.`);
    
    // Reset form and close modal
    setIssueData({ type: 'pest', description: '', severity: 'medium' });
    setShowIssueModal(false);
    setSelectedCrop(null);
    
    // Refresh crops data
    fetchData();
    
  } catch (error) {
    console.error('Report issue error:', error);
    const errorMessage = error.response?.data?.message || 'Failed to report issue. Please try again.';
    toast.error(errorMessage);
  } finally {
    setSubmittingIssue(false);
  }
};

  const openIssueModal = (crop) => {
    setSelectedCrop(crop);
    setIssueData({ type: 'pest', description: '', severity: 'medium' });
    setShowIssueModal(true);
  };

  const getGrowthProgress = (stage) => {
    const stages = ['planting', 'germination', 'vegetative', 'flowering', 'fruiting', 'maturing', 'harvesting'];
    const index = stages.indexOf(stage);
    return ((index + 1) / stages.length) * 100;
  };

  const getHealthColor = (health) => {
    const colors = {
      excellent: '#65a30d',
      good: '#84cc16',
      fair: '#ff9800',
      poor: '#f44336',
      critical: '#d32f2f'
    };
    return colors[health] || '#6c757d';
  };

  const getStageIcon = (stage) => {
    switch(stage) {
      case 'planting': return <FaSeedling style={{ color: '#84cc16' }} />;
      case 'germination': return <FaLeaf style={{ color: '#a3e635' }} />;
      case 'vegetative': return <FaTree style={{ color: '#65a30d' }} />;
      case 'flowering': return <FaLeaf style={{ color: '#ff9800' }} />;
      case 'fruiting': return <FaSeedling style={{ color: '#84cc16' }} />;
      default: return <FaClock style={{ color: '#9e9e9e' }} />;
    }
  };

  if (loading) {
    return (
      <>
        <Navbar />
        <div className="d-flex flex-column justify-content-center align-items-center" style={{ minHeight: '70vh', gap: '1rem' }}>
          <div style={{ position: 'relative', width: 56, height: 56 }}>
            <div style={{ position: 'absolute', inset: 0, borderRadius: '50%', border: '3px solid #ecfccb', borderTopColor: '#65a30d', animation: 'spin 0.9s linear infinite' }} />
            <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <FaLeaf style={{ color: '#84cc16', fontSize: '20px' }} />
            </div>
          </div>
          <p className="text-muted mb-0" style={{ fontSize: '0.9rem' }}>Loading crops...</p>
          <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
        </div>
      </>
    );
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', minHeight: '100vh' }}>
      <Navbar />
      <Container fluid className="mt-4 px-4 pb-5" style={{ flex: 1 }}>
        <div className="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-3">
          <div>
            <div className="d-flex align-items-center gap-2">
              <FaSeedling style={{ color: '#65a30d', fontSize: '28px' }} />
              <h2 className="gradient-text mb-1">My Crops</h2>
            </div>
            <p className="text-muted">Track and monitor your crop growth</p>
          </div>
          <Button variant="success" onClick={() => handleOpenModal()} className="btn-gradient" disabled={farms.length === 0}>
            <FaPlus className="me-2" style={{ color: '#ffffff' }} /> Add New Crop
          </Button>
        </div>

        {farms.length === 0 && (
          <Alert variant="warning" className="mb-4">
            <FaExclamationTriangle className="me-2" style={{ color: '#ff9800' }} />
            Please add a farm before adding crops.
          </Alert>
        )}

        {crops.length === 0 ? (
          <Card className="text-center py-5 shadow-sm">
            <Card.Body>
              <div style={{ width: '80px', height: '80px', margin: '0 auto 20px', display: 'flex', alignItems: 'center', justifyContent: 'center', backgroundColor: '#ecfccb', borderRadius: '50%' }}>
                <FaSeedling size={40} style={{ color: '#65a30d' }} />
              </div>
              <h4>No Crops Yet</h4>
              <p className="text-muted">Get started by adding your first crop.</p>
              {farms.length > 0 && (
                <Button variant="success" onClick={() => handleOpenModal()}>
                  <FaPlus className="me-2" style={{ color: '#ffffff' }} /> Add Your First Crop
                </Button>
              )}
            </Card.Body>
          </Card>
        ) : (
          <Row className="g-4">
            {crops.map((crop) => (
              <Col md={6} lg={4} key={crop._id}>
                <Card className="h-100 card-hover shadow-sm" style={{ display: 'flex', flexDirection: 'column' }}>
                  <Card.Body style={{ display: 'flex', flexDirection: 'column' }}>
                    <div className="d-flex justify-content-between align-items-start mb-3">
                      <div>
                        <div className="d-flex align-items-center gap-2 mb-2">
                          {getStageIcon(crop.growthStage)}
                          <h5 className="mb-0">{crop.name}</h5>
                        </div>
                        <div className="d-flex flex-wrap gap-2">
                          <Badge style={{ backgroundColor: getHealthColor(crop.health) }} className="px-2 py-1">
                            <FaHeartbeat className="me-1" style={{ color: '#ffffff' }} /> {crop.health}
                          </Badge>
                          <Badge style={{ backgroundColor: '#6c757d' }} className="px-2 py-1">
                            {crop.growthStage}
                          </Badge>
                        </div>
                      </div>
                      <div className="d-flex gap-1">
                        <Button 
                          variant="link" 
                          size="sm"
                          className="p-2 border-0"
                          style={{ backgroundColor: 'rgba(101, 163, 13, 0.1)', borderRadius: '8px' }}
                          onClick={() => handleOpenModal(crop)}
                        >
                          <FaEdit style={{ color: '#65a30d' }} />
                        </Button>
                        <Button 
                          variant="link" 
                          size="sm"
                          className="p-2 border-0"
                          style={{ backgroundColor: 'rgba(244, 67, 54, 0.1)', borderRadius: '8px' }}
                          onClick={() => handleDelete(crop._id)}
                        >
                          <FaTrash style={{ color: '#f44336' }} />
                        </Button>
                      </div>
                    </div>

                    <div className="mb-3">
                      <div className="d-flex justify-content-between mb-1">
                        <small className="text-muted">Growth Progress</small>
                        <small className="text-muted">{Math.round(getGrowthProgress(crop.growthStage))}%</small>
                      </div>
                      <ProgressBar 
                        now={getGrowthProgress(crop.growthStage)} 
                        variant="success" 
                        style={{ height: '8px', borderRadius: '4px' }}
                      />
                    </div>

                    <div className="mb-3">
                      {crop.variety && (
                        <div className="d-flex align-items-center mb-2">
                          <div className="me-2" style={{ width: '24px' }}>
                            <FaTag style={{ color: '#84cc16', fontSize: '12px' }} />
                          </div>
                          <small className="text-muted">Variety: {crop.variety}</small>
                        </div>
                      )}
                      <div className="d-flex align-items-center mb-2">
                        <div className="me-2" style={{ width: '24px' }}>
                          <FaCalendarAlt style={{ color: '#ff9800', fontSize: '12px' }} />
                        </div>
                        <small className="text-muted">Planted: {new Date(crop.plantingDate).toLocaleDateString()}</small>
                      </div>
                      {crop.expectedHarvestDate && (
                        <div className="d-flex align-items-center mb-2">
                          <div className="me-2" style={{ width: '24px' }}>
                            <FaCheckCircle style={{ color: '#84cc16', fontSize: '12px' }} />
                          </div>
                          <small className="text-muted">Expected Harvest: {new Date(crop.expectedHarvestDate).toLocaleDateString()}</small>
                        </div>
                      )}
                      {crop.areaPlanted?.value && (
                        <div className="d-flex align-items-center mb-2">
                          <div className="me-2" style={{ width: '24px' }}>
                            <FaRuler style={{ color: '#2196f3', fontSize: '12px' }} />
                          </div>
                          <small className="text-muted">Area: {crop.areaPlanted.value} {crop.areaPlanted.unit}</small>
                        </div>
                      )}
                    </div>

                    {crop.alerts && crop.alerts.length > 0 && (
                      <Alert variant="warning" className="p-2 small mb-3">
                        <FaExclamationTriangle className="me-1" style={{ color: '#ff9800' }} />
                        {crop.alerts[0].message || `${crop.alerts.length} alert(s) need attention`}
                      </Alert>
                    )}

                    <div className="mt-auto d-flex gap-2 pt-2" style={{ borderTop: '1px solid #f0f0f0' }}>
                      <Button 
                        variant="outline-warning" 
                        size="sm"
                        onClick={() => openIssueModal(crop)}
                        style={{ borderColor: '#ff9800', color: '#ff9800', flex: 1 }}
                      >
                        <FaBug className="me-1" style={{ color: '#ff9800' }} /> Report Issue
                      </Button>
                      <Button 
                        variant="outline-info" 
                        size="sm"
                        onClick={() => {
                          const stages = ['planting', 'germination', 'vegetative', 'flowering', 'fruiting', 'maturing', 'harvesting'];
                          const currentIndex = stages.indexOf(crop.growthStage);
                          if (currentIndex < stages.length - 1) {
                            handleStageChange(crop._id, stages[currentIndex + 1]);
                          } else {
                            toast.info('Crop is already in harvesting stage');
                          }
                        }}
                        style={{ borderColor: '#00bcd4', color: '#00bcd4', flex: 1 }}
                      >
                        <FaChartLine className="me-1" style={{ color: '#00bcd4' }} /> Next Stage
                      </Button>
                    </div>
                  </Card.Body>
                </Card>
              </Col>
            ))}
          </Row>
        )}

        {/* Add/Edit Crop Modal */}
        <Modal show={showModal} onHide={() => setShowModal(false)} size="lg">
          <Modal.Header closeButton style={{ background: 'linear-gradient(135deg, #65a30d, #84cc16)', color: 'white' }}>
            <Modal.Title>
              {editingCrop ? (
                <><FaEdit className="me-2" style={{ color: '#ffffff' }} /> Edit Crop</>
              ) : (
                <><FaPlus className="me-2" style={{ color: '#ffffff' }} /> Add New Crop</>
              )}
            </Modal.Title>
          </Modal.Header>
          <Form onSubmit={handleSubmit}>
            <Modal.Body>
              <Form.Group className="mb-3">
                <Form.Label className="fw-bold">Crop Name <span className="text-danger">*</span></Form.Label>
                <Form.Control
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                  placeholder="e.g., Rice, Wheat, Tomato"
                />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label className="fw-bold">Farm <span className="text-danger">*</span></Form.Label>
                <Form.Select
                  name="farm"
                  value={formData.farm}
                  onChange={(e) => setFormData({ ...formData, farm: e.target.value })}
                  required
                >
                  <option value="">Select farm</option>
                  {farms.map(farm => (
                    <option key={farm._id} value={farm._id}>{farm.name}</option>
                  ))}
                </Form.Select>
              </Form.Group>

              <Row>
                <Col md={6}>
                  <Form.Group className="mb-3">
                    <Form.Label>Variety</Form.Label>
                    <Form.Control
                      type="text"
                      name="variety"
                      value={formData.variety}
                      onChange={(e) => setFormData({ ...formData, variety: e.target.value })}
                      placeholder="e.g., Hybrid, Local"
                    />
                  </Form.Group>
                </Col>
                <Col md={6}>
                  <Form.Group className="mb-3">
                    <Form.Label>Planting Date</Form.Label>
                    <Form.Control
                      type="date"
                      name="plantingDate"
                      value={formData.plantingDate}
                      onChange={(e) => setFormData({ ...formData, plantingDate: e.target.value })}
                      required
                    />
                  </Form.Group>
                </Col>
              </Row>

              <Row>
                <Col md={6}>
                  <Form.Group className="mb-3">
                    <Form.Label>Expected Harvest Date</Form.Label>
                    <Form.Control
                      type="date"
                      name="expectedHarvestDate"
                      value={formData.expectedHarvestDate}
                      onChange={(e) => setFormData({ ...formData, expectedHarvestDate: e.target.value })}
                    />
                  </Form.Group>
                </Col>
                <Col md={6}>
                  <Form.Group className="mb-3">
                    <Form.Label>Growth Stage</Form.Label>
                    <Form.Select
                      name="growthStage"
                      value={formData.growthStage}
                      onChange={(e) => setFormData({ ...formData, growthStage: e.target.value })}
                    >
                      <option value="planting">Planting</option>
                      <option value="germination">Germination</option>
                      <option value="vegetative">Vegetative</option>
                      <option value="flowering">Flowering</option>
                      <option value="fruiting">Fruiting</option>
                      <option value="maturing">Maturing</option>
                      <option value="harvesting">Harvesting</option>
                    </Form.Select>
                  </Form.Group>
                </Col>
              </Row>

              <Row>
                <Col md={6}>
                  <Form.Group className="mb-3">
                    <Form.Label>Area Planted</Form.Label>
                    <Form.Control
                      type="number"
                      name="areaPlanted.value"
                      value={formData.areaPlanted.value}
                      onChange={(e) => setFormData({ 
                        ...formData, 
                        areaPlanted: { ...formData.areaPlanted, value: e.target.value }
                      })}
                      placeholder="Area"
                    />
                  </Form.Group>
                </Col>
                <Col md={6}>
                  <Form.Group className="mb-3">
                    <Form.Label>Unit</Form.Label>
                    <Form.Select
                      name="areaPlanted.unit"
                      value={formData.areaPlanted.unit}
                      onChange={(e) => setFormData({ 
                        ...formData, 
                        areaPlanted: { ...formData.areaPlanted, unit: e.target.value }
                      })}
                    >
                      <option value="acre">Acre</option>
                      <option value="hectare">Hectare</option>
                      <option value="sq-meter">Square Meter</option>
                    </Form.Select>
                  </Form.Group>
                </Col>
              </Row>
            </Modal.Body>
            <Modal.Footer>
              <Button variant="secondary" onClick={() => setShowModal(false)}>Cancel</Button>
              <Button type="submit" variant="success">{editingCrop ? 'Update' : 'Add'} Crop</Button>
            </Modal.Footer>
          </Form>
        </Modal>

        {/* Report Issue Modal - FIXED VERSION */}
        <Modal show={showIssueModal} onHide={() => setShowIssueModal(false)}>
          <Modal.Header closeButton style={{ background: 'linear-gradient(135deg, #ff9800, #f57c00)', color: 'white' }}>
            <Modal.Title>
              <FaBug className="me-2" style={{ color: '#ffffff' }} /> Report Issue for {selectedCrop?.name}
            </Modal.Title>
          </Modal.Header>
          <Form onSubmit={handleReportIssue}>
            <Modal.Body>
              <Form.Group className="mb-3">
                <Form.Label>Issue Type</Form.Label>
                <Form.Select
                  value={issueData.type}
                  onChange={(e) => setIssueData({ ...issueData, type: e.target.value })}
                >
                  <option value="pest">🐛 Pest Infestation</option>
                  <option value="disease">🦠 Disease</option>
                  <option value="nutrient">🌿 Nutrient Deficiency</option>
                  <option value="water">💧 Water Issue</option>
                </Form.Select>
              </Form.Group>
              
              <Form.Group className="mb-3">
                <Form.Label>Description <span className="text-danger">*</span></Form.Label>
                <Form.Control
                  as="textarea"
                  rows={4}
                  value={issueData.description}
                  onChange={(e) => setIssueData({ ...issueData, description: e.target.value })}
                  placeholder="Please describe the issue in detail. "
                  required
                />
                <Form.Text className="text-muted">
                  Provide as much detail as possible for accurate diagnosis.
                </Form.Text>
              </Form.Group>
              
              <Form.Group className="mb-3">
                <Form.Label>Severity Level</Form.Label>
                <Form.Select
                  value={issueData.severity}
                  onChange={(e) => setIssueData({ ...issueData, severity: e.target.value })}
                >
                  <option value="low">🟢 Low - Minor issue, isolated spots</option>
                  <option value="medium">🟡 Medium - Spreading, needs attention</option>
                  <option value="high">🔴 High - Widespread, urgent action needed</option>
                </Form.Select>
              </Form.Group>

              <Alert variant="info" className="mt-3">
                <FaInfoCircle className="me-2" />
                Our agricultural experts will review your report and provide recommendations within 24 hours.
              </Alert>
            </Modal.Body>
            <Modal.Footer>
              <Button variant="secondary" onClick={() => setShowIssueModal(false)}>
                Cancel
              </Button>
              <Button 
                type="submit" 
                variant="warning" 
                disabled={submittingIssue || !issueData.description.trim()}
              >
                {submittingIssue ? (
                  <><Spinner size="sm" className="me-2" /> Submitting...</>
                ) : (
                  <><FaPaperPlane className="me-2" /> Submit Report</>
                )}
              </Button>
            </Modal.Footer>
          </Form>
        </Modal>
      </Container>
      <Footer />

      <style>{`
        .gradient-text {
          background: linear-gradient(135deg, #65a30d, #84cc16);
          -webkit-background-clip: text;
          background-clip: text;
          color: transparent;
        }
        .btn-gradient {
          background: linear-gradient(135deg, #65a30d, #84cc16);
          border: none;
          transition: transform 0.3s ease;
        }
        .btn-gradient:hover {
          transform: translateY(-2px);
        }
        .card-hover {
          transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .card-hover:hover {
          transform: translateY(-5px);
          box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }
        @keyframes spin { to { transform: rotate(360deg); } }
      `}</style>
    </div>
  );
};

export default CropsPage;