import React from 'react';
import { Alert } from 'react-bootstrap';

const ErrorMessage = ({ message, onDismiss }) => {
  if (!message) return null;
  
  return (
    <Alert variant="danger" onClose={onDismiss} dismissible>
      <Alert.Heading>Error!</Alert.Heading>
      <p>{message}</p>
    </Alert>
  );
};

export default ErrorMessage;