import React from 'react';
import { Container, Row, Col } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import { FaLeaf, FaHeart } from 'react-icons/fa';

const Footer = () => {
  const year = new Date().getFullYear();

  return (
    <footer className="app-footer mt-auto">
      <Container>
        <Row className="align-items-center gy-3">
          <Col md={4}>
            <div className="d-flex align-items-center gap-2 mb-1">
              <FaLeaf style={{ color: '#bef264' }} />
              <span className="fw-bold text-white" style={{ fontSize: '1rem' }}>
                Agri<span style={{ color: '#bef264' }}>Tech</span>
              </span>
            </div>
            <p className="mb-0" style={{ fontSize: '0.78rem', color: 'rgba(255,255,255,0.6)' }}>
              Smart farming for modern agriculture
            </p>
          </Col>

          <Col md={4} className="text-center">
            <div className="d-flex justify-content-center gap-3" style={{ fontSize: '0.8rem' }}>
              <Link to="/dashboard">Dashboard</Link>
              <Link to="/farms">Farms</Link>
              <Link to="/forum">Forum</Link>
              <Link to="/marketplace">Market</Link>
            </div>
          </Col>

          <Col md={4} className="text-md-end">
            <p className="mb-0" style={{ fontSize: '0.78rem', color: 'rgba(255,255,255,0.6)' }}>
              © {year} AgriTech. Made with{' '}
              <FaHeart style={{ color: '#fca5a5', fontSize: '11px' }} /> for farmers.
            </p>
          </Col>
        </Row>
      </Container>
    </footer>
  );
};

export default Footer;
