import React, { useState, useEffect } from 'react';
import { Card, ListGroup, Badge } from 'react-bootstrap';
import { FaBell, FaBug, FaTint, FaCalendarAlt } from 'react-icons/fa';
import { getUserCrops } from '../../services/cropService';

const AlertsPanel = () => {
  const [alerts, setAlerts] = useState([]);

  useEffect(() => {
    fetchAlerts();
  }, []);

  const fetchAlerts = async () => {
    try {
      const crops = await getUserCrops();
      const allAlerts = crops.flatMap(crop => 
        (crop.alerts || []).map(alert => ({
          ...alert,
          cropName: crop.name,
          cropId: crop._id,
        }))
      ).sort((a, b) => new Date(b.date) - new Date(a.date));
      setAlerts(allAlerts.slice(0, 5));
    } catch (error) {
      console.error('Failed to fetch alerts');
    }
  };

  const getAlertIcon = (type) => {
    if (type.includes('pest') || type.includes('disease')) return <FaBug className="text-warning" />;
    if (type.includes('irrigation')) return <FaTint className="text-info" />;
    if (type.includes('harvest')) return <FaCalendarAlt className="text-success" />;
    return <FaBell className="text-primary" />;
  };

  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'danger': return 'danger';
      case 'warning': return 'warning';
      default: return 'info';
    }
  };

  if (alerts.length === 0) {
    return (
      <Card className="shadow-sm">
        <Card.Header className="bg-white">
          <h5 className="mb-0"><FaBell className="me-2 text-success" />Alerts & Notifications</h5>
        </Card.Header>
        <Card.Body className="text-center py-4">
          <p className="text-muted mb-0">No new alerts. Your crops are doing well! 🌾</p>
        </Card.Body>
      </Card>
    );
  }

  return (
    <Card className="shadow-sm">
      <Card.Header className="bg-white">
        <h5 className="mb-0"><FaBell className="me-2 text-success" />Recent Alerts</h5>
      </Card.Header>
      <ListGroup variant="flush">
        {alerts.map((alert, idx) => (
          <ListGroup.Item key={idx} className="d-flex align-items-start">
            <div className="me-3 mt-1">{getAlertIcon(alert.type)}</div>
            <div className="flex-grow-1">
              <div className="fw-bold">{alert.message || alert.type}</div>
              <small className="text-muted">{alert.cropName}</small>
              <Badge bg={getSeverityColor(alert.severity)} className="ms-2">{alert.severity}</Badge>
              <div className="small text-muted mt-1">{new Date(alert.date).toLocaleDateString()}</div>
            </div>
          </ListGroup.Item>
        ))}
      </ListGroup>
    </Card>
  );
};

export default AlertsPanel;