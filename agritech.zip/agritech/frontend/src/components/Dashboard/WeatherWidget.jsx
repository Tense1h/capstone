import React, { useState, useEffect } from 'react';
import { Card, Form, Button, Alert, Spinner, Row, Col } from 'react-bootstrap';
import { 
  WiDaySunny, WiCloudy, WiRain, WiSnow, WiThunderstorm, 
  WiFog, WiHumidity, WiStrongWind, WiBarometer
} from 'react-icons/wi';
import { FaTint, FaMapMarkerAlt, FaSearch, FaLocationArrow, FaLeaf, FaExclamationTriangle, FaCity } from 'react-icons/fa';
import { getCurrentWeather, getWeatherByCity, getWeatherForecast } from '../../services/weatherService';
import { toast } from 'react-toastify';

const WeatherWidget = () => {
  const [weather, setWeather] = useState(null);
  const [forecast, setForecast] = useState(null);
  const [loading, setLoading] = useState(false);
  const [city, setCity] = useState('');
  const [error, setError] = useState(null);
  const [recommendations, setRecommendations] = useState([]);
  const [locationPermission, setLocationPermission] = useState(null); 


  const defaultCity = "Manila";

  useEffect(() => {
    checkLocationPermissionAndGetWeather();
  }, []);

  const checkLocationPermissionAndGetWeather = async () => {
    if (!navigator.geolocation) {
      setError('Geolocation is not supported by your browser. Please search for a city manually.');
      setLocationPermission('denied');
      await fetchWeatherByCity(defaultCity);
      return;
    }

    // Check permission status
    navigator.permissions.query({ name: 'geolocation' }).then((result) => {
      if (result.state === 'granted') {
        setLocationPermission('granted');
        getUserLocation();
      } else if (result.state === 'prompt') {
        setLocationPermission('prompt');
        getUserLocation();
      } else {
        setLocationPermission('denied');
        setError('Location access denied. Please search for a city manually or enable location in your browser settings.');
        fetchWeatherByCity(defaultCity);
      }
    }).catch(() => {
      getUserLocation();
    });
  };

  const getUserLocation = () => {
    if (!navigator.geolocation) {
      setError('Geolocation not supported');
      fetchWeatherByCity(defaultCity);
      return;
    }

    setLoading(true);
    
    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const { latitude, longitude } = position.coords;
        await fetchWeather(latitude, longitude);
        setLocationPermission('granted');
        setLoading(false);
      },
      (err) => {
        console.error('Geolocation error:', err);
        let errorMessage = 'Unable to get your location. ';
        
        switch(err.code) {
          case err.PERMISSION_DENIED:
            errorMessage += 'Please allow location access or search for a city manually.';
            break;
          case err.POSITION_UNAVAILABLE:
            errorMessage += 'Location information is unavailable. Please search for a city.';
            break;
          case err.TIMEOUT:
            errorMessage += 'Location request timed out. Please try searching for a city.';
            break;
          default:
            errorMessage += 'Please search for a city manually.';
        }
        
        setError(errorMessage);
        setLocationPermission('denied');
        setLoading(false);
        // Load default city weather
        fetchWeatherByCity(defaultCity);
      },
      { timeout: 10000, enableHighAccuracy: false }
    );
  };

  const fetchWeather = async (lat, lon) => {
    setLoading(true);
    try {
      const weatherData = await getCurrentWeather(lat, lon);
      const forecastData = await getWeatherForecast(lat, lon);
      setWeather(weatherData);
      setForecast(forecastData.list?.slice(0, 5) || []);
      setRecommendations(weatherData.agriculturalRecommendations || []);
      setError(null);
    } catch (err) {
      console.error('Weather fetch error:', err);
      setError('Failed to fetch weather data. Please check your internet connection.');
      toast.error('Weather fetch failed');
    } finally {
      setLoading(false);
    }
  };

  const fetchWeatherByCity = async (cityName) => {
    if (!cityName.trim()) return;
    
    setLoading(true);
    try {
      const weatherData = await getWeatherByCity(cityName);
      setWeather(weatherData);
      const forecastData = await getWeatherForecast(weatherData.coord.lat, weatherData.coord.lon);
      setForecast(forecastData.list?.slice(0, 5) || []);
      setRecommendations(weatherData.agriculturalRecommendations || []);
      setError(null);
    } catch (err) {
      console.error('City weather fetch error:', err);
      setError(`City "${cityName}" not found. Please try another city.`);
      toast.error('City not found');
    } finally {
      setLoading(false);
    }
  };

  const handleCitySearch = async (e) => {
    e.preventDefault();
    if (!city.trim()) {
      toast.error('Please enter a city name');
      return;
    }
    await fetchWeatherByCity(city);
    setCity('');
  };

  const handleUseCurrentLocation = () => {
    if (locationPermission === 'denied') {
      toast.info('Please enable location in your browser settings, or search for a city manually.');
      return;
    }
    getUserLocation();
  };

  const getWeatherIcon = (condition) => {
    const main = condition?.toLowerCase() || '';
    if (main.includes('clear')) return <WiDaySunny size={64} style={{ color: '#ff9800' }} />;
    if (main.includes('cloud')) return <WiCloudy size={64} style={{ color: '#607d8b' }} />;
    if (main.includes('rain')) return <WiRain size={64} style={{ color: '#2196f3' }} />;
    if (main.includes('snow')) return <WiSnow size={64} style={{ color: '#00bcd4' }} />;
    if (main.includes('thunder')) return <WiThunderstorm size={64} style={{ color: '#f44336' }} />;
    if (main.includes('fog')) return <WiFog size={64} style={{ color: '#9e9e9e' }} />;
    return <WiDaySunny size={64} style={{ color: '#ff9800' }} />;
  };

  // Helper to get city name from weather data or default
  const getCityName = () => {
    if (weather?.name) return weather.name;
    return defaultCity;
  };

  if (loading && !weather) {
    return (
      <Card className="weather-card mb-4 shadow-sm border-0" style={{ borderRadius: '16px' }}>
        <Card.Body className="text-center py-5">
          <div style={{ position: 'relative', width: 48, height: 48, margin: '0 auto 12px' }}>
            <div style={{ position: 'absolute', inset: 0, borderRadius: '50%', border: '3px solid #ecfccb', borderTopColor: '#65a30d', animation: 'spin 0.9s linear infinite' }} />
            <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <FaLeaf style={{ color: '#84cc16', fontSize: '16px' }} />
            </div>
          </div>
          <p className="text-muted mb-0" style={{ fontSize: '0.875rem' }}>Loading weather data...</p>
          <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
        </Card.Body>
      </Card>
    );
  }

  return (
    <Card className="weather-card mb-4 shadow-sm border-0" style={{ borderRadius: '16px', overflow: 'hidden' }}>
      <Card.Header className="bg-white border-0 pt-4 pb-2">
        <div className="d-flex align-items-center justify-content-between flex-wrap gap-2">
          <div className="d-flex align-items-center gap-2">
            <FaLeaf style={{ color: '#65a30d', fontSize: '20px' }} />
            <h5 className="mb-0" style={{ color: '#65a30d' }}>Weather & Farming Insights</h5>
          </div>
          {locationPermission === 'denied' && (
            <small className="text-muted">
              <FaExclamationTriangle style={{ color: '#ff9800' }} className="me-1" />
              Location disabled
            </small>
          )}
        </div>
      </Card.Header>
      
      <Card.Body>
        <Form onSubmit={handleCitySearch} className="mb-4">
          <div className="d-flex gap-2">
            <div className="position-relative flex-grow-1">
              <FaSearch style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: '#9e9e9e', fontSize: '14px' }} />
              <Form.Control
                type="text"
                placeholder="Search city"
                value={city}
                onChange={(e) => setCity(e.target.value)}
                className="rounded-pill"
                style={{ paddingLeft: '35px' }}
              />
            </div>
            <Button type="submit" variant="success" className="rounded-pill px-4 btn-gradient">
              Search
            </Button>
            <Button 
              variant="outline-success" 
              onClick={handleUseCurrentLocation} 
              className="rounded-pill"
              style={{ borderColor: '#84cc16', color: '#84cc16' }}
              title="Use my current location"
            >
              <FaLocationArrow />
            </Button>
          </div>
          {locationPermission === 'denied' && (
            <Form.Text className="text-muted d-block mt-2">
              <small>📍 Location access is blocked. You can search for any city manually above.</small>
            </Form.Text>
          )}
        </Form>

        {error && (
          <Alert variant="warning" className="rounded-3">
            <FaExclamationTriangle className="me-2" style={{ color: '#ff9800' }} />
            {error}
          </Alert>
        )}

        {weather ? (
          <>
            <div className="text-center mb-4">
              <div className="d-flex justify-content-between align-items-center">
                <div className="text-start">
                  <div className="d-flex align-items-center gap-1">
                    <FaCity style={{ color: '#f44336', fontSize: '12px' }} />
                    <h3 className="mb-0" style={{ fontSize: '1.5rem' }}>{getCityName()}</h3>
                  </div>
                  <p className="text-muted mb-0 small">{weather.sys?.country}</p>
                </div>
                <div>{getWeatherIcon(weather.weather?.[0]?.main)}</div>
              </div>
              <div className="mt-3">
                <span className="display-2 fw-bold" style={{ 
                  background: 'linear-gradient(135deg, #65a30d, #84cc16)',
                  WebkitBackgroundClip: 'text',
                  backgroundClip: 'text',
                  color: 'transparent',
                  fontSize: '3rem'
                }}>
                  {Math.round(weather.main?.temp)}°C
                </span>
              </div>
              <p className="text-capitalize text-muted mt-2">{weather.weather?.[0]?.description}</p>
            </div>

            <Row className="text-center mb-4 g-2">
              <Col xs={4}>
                <div className="p-2 rounded-3" style={{ backgroundColor: '#e3f2fd' }}>
                  <WiHumidity size={28} style={{ color: '#0277bd' }} />
                  <div className="fw-bold">{weather.main?.humidity}%</div>
                  <small className="text-muted">Humidity</small>
                </div>
              </Col>
              <Col xs={4}>
                <div className="p-2 rounded-3" style={{ backgroundColor: '#f3e5f5' }}>
                  <WiStrongWind size={28} style={{ color: '#7b1fa2' }} />
                  <div className="fw-bold">{Math.round(weather.wind?.speed)} m/s</div>
                  <small className="text-muted">Wind</small>
                </div>
              </Col>
              <Col xs={4}>
                <div className="p-2 rounded-3" style={{ backgroundColor: '#fff3e0' }}>
                  <WiBarometer size={28} style={{ color: '#ef6c00' }} />
                  <div className="fw-bold">{weather.main?.pressure} hPa</div>
                  <small className="text-muted">Pressure</small>
                </div>
              </Col>
            </Row>

            {recommendations.length > 0 && (
              <div className="mt-3 p-3 rounded-3" style={{ backgroundColor: '#ecfccb' }}>
                <h6 className="mb-3" style={{ color: '#65a30d' }}>
                  <FaLeaf className="me-2" /> Agricultural Recommendations:
                </h6>
                {recommendations.map((rec, idx) => (
                  <div 
                    key={idx} 
                    className="mb-2 p-2 rounded"
                    style={{ 
                      backgroundColor: rec.type === 'warning' ? '#fff3e0' : 
                                    rec.type === 'alert' ? '#ffebee' : 
                                    '#d9f99d'
                    }}
                  >
                    <div className="fw-bold small">{rec.message}</div>
                    <small className="text-muted">{rec.action}</small>
                  </div>
                ))}
              </div>
            )}

            {forecast && forecast.length > 0 && (
              <div className="mt-4">
                <h6 className="mb-3" style={{ color: '#65a30d' }}>5-Day Forecast:</h6>
                <div className="d-flex justify-content-between overflow-auto pb-2" style={{ gap: '8px' }}>
                  {forecast.map((item, idx) => (
                    <div key={idx} className="text-center p-2 rounded-3 flex-shrink-0" style={{ minWidth: '70px', backgroundColor: '#f5f5f5' }}>
                      <div className="small fw-bold">{new Date(item.dt * 1000).toLocaleDateString('en-US', { weekday: 'short' })}</div>
                      {getWeatherIcon(item.weather?.[0]?.main)}
                      <div className="fw-bold mt-1">{Math.round(item.main?.temp_max)}°</div>
                      <small className="text-muted">{Math.round(item.main?.temp_min)}°</small>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </>
        ) : (
          <div className="text-center py-4">
            <FaCity size={48} className="text-muted mb-3" />
            <p className="text-muted">Search for a city to see weather information</p>
            <small className="text-muted">Try: Manila, New York, London, Tokyo</small>
          </div>
        )}
      </Card.Body>

      <style>{`
        .weather-card {
          transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .weather-card:hover {
          transform: translateY(-3px);
          box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }
        .btn-gradient {
          background: linear-gradient(135deg, #65a30d, #84cc16);
          border: none;
          transition: transform 0.3s ease;
        }
        .btn-gradient:hover {
          transform: translateY(-2px);
        }
      `}</style>
    </Card>
  );
};

export default WeatherWidget;