================================================================
  AGRITECH CONNECT — README: HOW TO RUN THE SYSTEM
  Smart Farm Management Platform | MERN Stack | v1.0.0
================================================================

  Backend  : Node.js + Express  | Port 5000
  Frontend : React 18 + Vite   | Port 5173
  Database : MongoDB (Mongoose) | Atlas or Local
  Auth     : JWT (30-day token)
  Weather  : OpenWeatherMap API

================================================================
  1. PREREQUISITES
================================================================

Install these before anything else:

  - Node.js v18+     https://nodejs.org
  - npm v9+          (comes with Node.js)
  - MongoDB Atlas    https://www.mongodb.com/atlas  (free tier)
    OR local MongoDB v7+
  - OpenWeatherMap API key  https://openweathermap.org/api  (free)
  - Git              https://git-scm.com

Verify Node.js is installed:
  node -v
  npm -v


================================================================
  2. PROJECT FOLDER STRUCTURE
================================================================

After unzipping capstone.zip:

  capstone/agritech/
  ├── backend/
  │   ├── server.js          ← main server entry point
  │   ├── .env               ← YOU must create this file
  │   ├── package.json       ← backend dependencies
  │   ├── create-admin.js    ← one-time admin account script
  │   ├── config/            ← database connection
  │   ├── controllers/       ← business logic
  │   ├── middleware/        ← JWT auth, role check
  │   ├── models/            ← MongoDB schemas
  │   ├── routes/            ← API endpoints
  │   └── uploads/           ← image storage
  └── frontend/
      ├── src/               ← React components & pages
      ├── package.json       ← frontend dependencies
      └── vite.config.js     ← Vite bundler config


================================================================
  3. STEP-BY-STEP SETUP
================================================================

----------------------------------
  STEP 1 — Extract the Project
----------------------------------

Unzip capstone.zip. You should see:
  capstone/agritech/backend/
  capstone/agritech/frontend/


----------------------------------
  STEP 2 — Create the .env File
----------------------------------

Go to:  capstone/agritech/backend/

Create a new file named:  .env   (dot prefix, no extension)

Paste this inside and fill in your own values:

  ----------------------------------------------------------------
  # MongoDB
  MONGODB_URI=mongodb+srv://<username>:<password>@cluster0.xxxxx.mongodb.net/agritech

  # JWT Secret (make this a long random string)
  JWT_SECRET=your_strong_random_secret_key_here

  # OpenWeatherMap
  OPENWEATHER_API_KEY=your_openweathermap_api_key_here

  # Server port (optional, default is 5000)
  PORT=5000
  ----------------------------------------------------------------

  NOTE: The key must be MONGODB_URI (not MONGO_URI).
  NOTE: Get your Atlas URI from: Atlas → Connect → Drivers → copy string.
        Replace <username> and <password> with your Atlas credentials.


----------------------------------
  STEP 3 — Install Backend
----------------------------------

Open a terminal and run:

  cd capstone/agritech/backend
  npm install

Wait for it to finish. A node_modules/ folder will appear.


----------------------------------
  STEP 4 — Install Frontend
----------------------------------

Open a SECOND terminal and run:

  cd capstone/agritech/frontend
  npm install


----------------------------------
  STEP 5 — Create Admin Account
  (Run once only)
----------------------------------

In the backend terminal:

  cd capstone/agritech/backend
  node create-admin.js

Expected output:
  ✅ Admin account created!
  ─────────────────────────
    Email   : admin@agritech.com
    Password: Admin@1234
  ─────────────────────────

  NOTE: Run this only once. If you run it again it will say
        "Admin account already exists" — that is normal.


================================================================
  4. RUNNING THE APPLICATION
================================================================

You need TWO terminal windows open at the same time.

----------------------------------
  Terminal 1 — Backend
----------------------------------

  cd capstone/agritech/backend
  npm run dev

Expected output:
  🚀 Server running on port 5000
  🌾 Agri-Tech API ready at http://localhost:5000
  ✔️  MongoDB Connected: cluster0.xxxxx.mongodb.net


----------------------------------
  Terminal 2 — Frontend
----------------------------------

  cd capstone/agritech/frontend
  npm run dev

Expected output:
  VITE v4.x.x  ready in XXX ms
  ➜  Local:  http://localhost:5173/


----------------------------------
  Open in Browser
----------------------------------

  http://localhost:5173

Health check (verify backend):
  http://localhost:5000/api/health
  → Should return: { "status": "OK", ... }


================================================================
  5. LOGIN CREDENTIALS
================================================================

  Role    | Email                  | Password
  --------|------------------------|------------------
  Admin   | admin@agritech.com     | Admin@1234
  Farmer  | register a new account | your own password
  Expert  | register a new account | your own password

  Farmers and Experts register at: http://localhost:5173/register
  Admin cannot self-register — only created via create-admin.js


================================================================
  6. AVAILABLE PAGES
================================================================

  http://localhost:5173/             Home (public)
  http://localhost:5173/login        Login
  http://localhost:5173/register     Register (farmer / expert)
  http://localhost:5173/dashboard    Farmer Dashboard
  http://localhost:5173/farms        Farm management
  http://localhost:5173/crops        Crop lifecycle tracking
  http://localhost:5173/marketplace  Browse & book products
  http://localhost:5173/forum        Community forum
  http://localhost:5173/analytics    Charts (yield & weather)
  http://localhost:5173/admin        Admin Dashboard
  http://localhost:5173/profile      User profile


================================================================
  7. NPM COMMANDS
================================================================

  BACKEND (run inside capstone/agritech/backend/)
  ------------------------------------------------
  npm install           Install all dependencies (first-time)
  npm run dev           Start with nodemon (auto-restart)
  npm start             Start without nodemon (production)
  node create-admin.js  Create admin account (once)
  node migrate-crops.js Seed crop data (optional)

  FRONTEND (run inside capstone/agritech/frontend/)
  --------------------------------------------------
  npm install           Install all dependencies (first-time)
  npm run dev           Start Vite dev server
  npm run build         Build for production (outputs to dist/)
  npm run preview       Preview production build locally


================================================================
  8. TROUBLESHOOTING
================================================================

  PROBLEM                          | SOLUTION
  ---------------------------------|-------------------------------
  MONGODB_URI is not defined       | Check .env is in backend/ and
                                   | key is MONGODB_URI exactly
  ---------------------------------|-------------------------------
  MongoNetworkError / timeout      | Atlas → Network Access →
                                   | Allow 0.0.0.0/0
  ---------------------------------|-------------------------------
  Port 5000 already in use         | Add PORT=5001 to .env
  ---------------------------------|-------------------------------
  Port 5173 already in use         | Vite auto-picks next port;
                                   | check terminal for actual URL
  ---------------------------------|-------------------------------
  CORS error in browser            | Make sure backend runs on 5000
  ---------------------------------|-------------------------------
  'npm' is not recognized          | Install Node.js from nodejs.org
                                   | then reopen terminal
  ---------------------------------|-------------------------------
  Cannot find module               | Run npm install in both
                                   | backend/ and frontend/
  ---------------------------------|-------------------------------
  Weather widget shows error       | Check OPENWEATHER_API_KEY in
                                   | .env (takes a few mins after
                                   | signup to activate)
  ---------------------------------|-------------------------------
  White/blank screen in browser    | Press F12 → Console for errors.
                                   | Usually backend not running.
  ---------------------------------|-------------------------------
  Admin page shows 403             | Login as admin@agritech.com
  ---------------------------------|-------------------------------
  Images not displaying            | Backend must be running —
                                   | images served from port 5000


================================================================
  9. QUICK START CHECKLIST
================================================================

  [ ] Node.js v18+ installed           node -v
  [ ] MongoDB Atlas URI ready          from atlas.mongodb.com
  [ ] OpenWeatherMap API key ready     from openweathermap.org
  [ ] .env file created in backend/    (3 variables filled in)
  [ ] npm install done in backend/     cd backend && npm install
  [ ] npm install done in frontend/    cd frontend && npm install
  [ ] Admin account created            node create-admin.js
  [ ] Backend running (Terminal 1)     npm run dev in backend/
  [ ] Frontend running (Terminal 2)    npm run dev in frontend/
  [ ] Browser open at localhost:5173   login: admin@agritech.com
  [ ] Health check OK at :5000/api/health

================================================================
  Happy Farming! 🌾
================================================================
