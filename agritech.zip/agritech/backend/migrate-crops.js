const mongoose = require('mongoose');
const dotenv = require('dotenv');
dotenv.config();

const Crop = require('./models/Crop');

const migrateAlerts = async () => {
  try {
    await mongoose.connect(process.env.MONGODB_URI);
    console.log('Connected to MongoDB');
    
    // Find all crops
    const crops = await Crop.find({});
    console.log(`Found ${crops.length} crops to check`);
    
    let updatedCount = 0;
    
    for (const crop of crops) {
      let needsUpdate = false;
      
      // Check if alerts exist and need migration
      if (crop.alerts && crop.alerts.length > 0) {
        // Check if any alert is a string (old format)
        const hasStringAlert = crop.alerts.some(alert => typeof alert === 'string');
        
        if (hasStringAlert) {
          // Convert string alerts to object format
          const newAlerts = crop.alerts.map(alert => {
            if (typeof alert === 'string') {
              return {
                type: 'general',
                message: alert,
                severity: 'info',
                date: new Date(),
                isRead: false
              };
            }
            return alert;
          });
          
          crop.alerts = newAlerts;
          needsUpdate = true;
        }
      } else if (!crop.alerts) {
        // Initialize alerts array if it doesn't exist
        crop.alerts = [];
        needsUpdate = true;
      }
      
      if (needsUpdate) {
        await crop.save();
        updatedCount++;
        console.log(`Updated crop: ${crop.name}`);
      }
    }
    
    console.log(`✅ Migration complete! Updated ${updatedCount} crops.`);
    process.exit(0);
  } catch (error) {
    console.error('Migration error:', error);
    process.exit(1);
  }
};

migrateAlerts();