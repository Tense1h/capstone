const dns = require('dns');
dns.setServers(['8.8.8.8', '8.8.4.4']);
dns.setDefaultResultOrder('ipv4first');

const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const path = require('path');
const fs = require('fs');
const multer = require('multer');

dotenv.config();

const { protect } = require('./middleware/auth');
const connectDB = require('./config/db');

connectDB();

const app = express();

const uploadDir = './uploads';
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, uploadDir);
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    const ext = path.extname(file.originalname);
    cb(null, file.fieldname + '-' + uniqueSuffix + ext);
  }
});

const fileFilter = (req, file, cb) => {
  const allowedTypes = /jpeg|jpg|png|gif|webp/;
  const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
  const mimetype = allowedTypes.test(file.mimetype);
  
  if (mimetype && extname) {
    return cb(null, true);
  } else {
    cb(new Error('Only image files are allowed (jpeg, jpg, png, gif, webp)'));
  }
};

const upload = multer({
  storage: storage,
  limits: {
    fileSize: 5 * 1024 * 1024 // 5MB limit
  },
  fileFilter: fileFilter
});

app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

app.use(cors({
  origin: ['http://localhost:5173', 'http://localhost:3000', 'http://127.0.0.1:5173'],
  credentials: true
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'OK', 
    message: 'Agri-Tech API is running', 
    timestamp: new Date(),
    dns: 'Using Google DNS (8.8.8.8)'
  });
});


app.post('/api/upload/single', protect, upload.single('image'), (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ message: 'No file uploaded' });
    }
    const imageUrl = `/uploads/${req.file.filename}`;
    res.json({ 
      success: true, 
      url: imageUrl,
      message: 'Image uploaded successfully'
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

app.post('/api/upload/multiple', protect, upload.array('images', 10), (req, res) => {
  try {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({ message: 'No files uploaded' });
    }
    const imageUrls = req.files.map(file => `/uploads/${file.filename}`);
    res.json({ 
      success: true, 
      urls: imageUrls,
      count: imageUrls.length,
      message: `${imageUrls.length} images uploaded successfully`
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

app.delete('/api/upload/:filename', protect, async (req, res) => {
  try {
    const uploadsDir = path.resolve(__dirname, 'uploads');
    const filepath = path.resolve(uploadsDir, req.params.filename);

    // Prevent path traversal: ensure resolved path is inside uploads directory
    if (!filepath.startsWith(uploadsDir + path.sep) && filepath !== uploadsDir) {
      return res.status(400).json({ message: 'Invalid filename' });
    }

    if (fs.existsSync(filepath)) {
      fs.unlinkSync(filepath);
      res.json({ success: true, message: 'Image deleted successfully' });
    } else {
      res.status(404).json({ message: 'Image not found' });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

app.use('/api/auth', require('./routes/auth'));
app.use('/api/farms', require('./routes/farms'));
app.use('/api/crops', require('./routes/crops'));
app.use('/api/products', require('./routes/products'));
app.use('/api/bookings', require('./routes/bookings'));
app.use('/api/forum', require('./routes/forum'));
app.use('/api/weather', require('./routes/weather'));
app.use('/api/admin', require('./routes/admin'));
app.use('/api/expert', require('./routes/expert'));

app.use('*', (req, res) => {
  res.status(404).json({ 
    message: `Cannot find ${req.originalUrl} on this server`,
    suggestion: 'Check if the route is registered in routes folder'
  });
});

app.use((err, req, res, next) => {
  console.error('Error:', err.stack);
  
  if (err instanceof multer.MulterError) {
    if (err.code === 'FILE_TOO_LARGE') {
      return res.status(400).json({ message: 'File too large. Max size is 5MB' });
    }
    return res.status(400).json({ message: err.message });
  }
  
  res.status(err.status || 500).json({
    message: err.message || 'Internal server error',
    stack: process.env.NODE_ENV === 'development' ? err.stack : undefined
  });
});

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
  console.log(`🌾 Agri-Tech API ready at http://localhost:${PORT}`);
  console.log(`📡 DNS configured to use Google DNS (8.8.8.8) for MongoDB resolution`);
  console.log(`🖼️  Image upload endpoint: http://localhost:${PORT}/api/upload`);
  console.log(`📁 Uploaded images served from: http://localhost:${PORT}/uploads/`);
});