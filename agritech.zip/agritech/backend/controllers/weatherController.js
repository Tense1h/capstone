const axios = require('axios');

// @desc    Get weather by coordinates
// @route   GET /api/weather/current
// @access  Public
const getWeatherByLocation = async (req, res) => {
  try {
    const { lat, lon } = req.query;
    
    if (!lat || !lon) {
      return res.status(400).json({ message: 'Latitude and longitude are required' });
    }
    
    const response = await axios.get(
      `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${process.env.OPENWEATHER_API_KEY}&units=metric`
    );
    
    // Add agricultural recommendations based on weather
    const weatherData = response.data;
    const recommendations = getWeatherRecommendations(weatherData);
    
    res.json({
      ...weatherData,
      agriculturalRecommendations: recommendations,
    });
  } catch (error) {
    console.error('Weather API error:', error.message);
    res.status(500).json({ message: 'Failed to fetch weather data' });
  }
};

// @desc    Get weather by city name
// @route   GET /api/weather/city
// @access  Public
const getWeatherByCity = async (req, res) => {
  try {
    const { city } = req.query;
    
    if (!city) {
      return res.status(400).json({ message: 'City name is required' });
    }
    
    const response = await axios.get(
      `https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(city)}&appid=${process.env.OPENWEATHER_API_KEY}&units=metric`
    );
    
    const recommendations = getWeatherRecommendations(response.data);
    
    res.json({
      ...response.data,
      agriculturalRecommendations: recommendations,
    });
  } catch (error) {
    if (error.response && error.response.status === 404) {
      res.status(404).json({ message: 'City not found' });
    } else {
      res.status(500).json({ message: 'Failed to fetch weather data' });
    }
  }
};

// @desc    Get 5-day forecast
// @route   GET /api/weather/forecast
// @access  Public
const getForecast = async (req, res) => {
  try {
    const { lat, lon } = req.query;
    
    if (!lat || !lon) {
      return res.status(400).json({ message: 'Latitude and longitude are required' });
    }
    
    const response = await axios.get(
      `https://api.openweathermap.org/data/2.5/forecast?lat=${lat}&lon=${lon}&appid=${process.env.OPENWEATHER_API_KEY}&units=metric`
    );
    
    // Process forecast for agricultural insights
    const processedForecast = processForecastForAgriculture(response.data.list);
    
    res.json({
      list: response.data.list,
      agriculturalInsights: processedForecast,
    });
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch forecast data' });
  }
};

// Helper: Generate weather-based recommendations
const getWeatherRecommendations = (weatherData) => {
  const recommendations = [];
  const temp = weatherData.main.temp;
  const humidity = weatherData.main.humidity;
  const weatherMain = weatherData.weather[0].main.toLowerCase();
  const windSpeed = weatherData.wind.speed;
  
  if (weatherMain.includes('rain')) {
    recommendations.push({
      type: 'warning',
      message: 'Rain expected. Postpone fertilizer and pesticide application.',
      action: 'Cover sensitive crops and ensure proper drainage.',
    });
  }
  
  if (temp > 35) {
    recommendations.push({
      type: 'alert',
      message: 'High temperature warning!',
      action: 'Increase irrigation frequency. Provide shade for young plants.',
    });
  } else if (temp < 10) {
    recommendations.push({
      type: 'alert',
      message: 'Low temperature warning!',
      action: 'Protect sensitive crops from frost. Consider using row covers.',
    });
  }
  
  if (humidity > 80) {
    recommendations.push({
      type: 'caution',
      message: 'High humidity levels detected',
      action: 'Monitor for fungal diseases. Ensure good air circulation.',
    });
  }
  
  if (windSpeed > 10) {
    recommendations.push({
      type: 'caution',
      message: 'Strong winds expected',
      action: 'Secure greenhouse structures. Avoid spraying operations.',
    });
  }
  
  if (weatherMain.includes('clear') && temp >= 20 && temp <= 30) {
    recommendations.push({
      type: 'ideal',
      message: 'Perfect weather for farming operations!',
      action: 'Ideal for planting, harvesting, and field work.',
    });
  }
  
  return recommendations;
};

// Helper: Process forecast for agriculture
const processForecastForAgriculture = (forecastList) => {
  const insights = {
    bestPlantingDays: [],
    irrigationNeeded: [],
    pestRisk: 'low',
    summary: '',
  };
  
  forecastList.forEach((item, index) => {
    const date = new Date(item.dt * 1000);
    const temp = item.main.temp;
    const weather = item.weather[0].main.toLowerCase();
    
    if (temp >= 20 && temp <= 30 && !weather.includes('rain')) {
      insights.bestPlantingDays.push(date.toLocaleDateString());
    }
    
    if (temp > 28 && !weather.includes('rain')) {
      insights.irrigationNeeded.push(date.toLocaleDateString());
    }
  });
  
  return insights;
};

module.exports = {
  getWeatherByLocation,
  getWeatherByCity,
  getForecast,
};