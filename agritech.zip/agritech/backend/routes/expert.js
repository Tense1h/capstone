const express = require('express');
const {
  createAdvice,
  getAllAdvice,
  getAdviceById,
  updateAdvice,
  deleteAdvice,
  likeAdvice,
  getPendingQuestions,
} = require('../controllers/expertController');
const { protect } = require('../middleware/auth');
const roleCheck = require('../middleware/roleCheck');

const router = express.Router();

router.get('/advice', getAllAdvice);
router.get('/advice/:id', getAdviceById);
router.get('/pending-questions', protect, roleCheck('expert'), getPendingQuestions);
router.post('/advice', protect, roleCheck('expert'), createAdvice);
router.put('/advice/:id', protect, roleCheck('expert'), updateAdvice);
router.delete('/advice/:id', protect, roleCheck('expert'), deleteAdvice);
router.post('/advice/:id/like', protect, likeAdvice);

module.exports = router;