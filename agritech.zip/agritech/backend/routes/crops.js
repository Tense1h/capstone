const express = require('express');
const {
  addCrop,
  getUserCrops,
  getCropsByFarm,
  getCropById,
  updateCrop,
  updateGrowthStage,
  reportIssue,
  deleteCrop,
} = require('../controllers/cropController');
const { protect } = require('../middleware/auth');

const router = express.Router();

router.route('/')
  .post(protect, addCrop)
  .get(protect, getUserCrops);

router.get('/farm/:farmId', protect, getCropsByFarm);
router.put('/:id/growth-stage', protect, updateGrowthStage);
router.post('/:id/report-issue', protect, reportIssue);
router.route('/:id')
  .get(protect, getCropById)
  .put(protect, updateCrop)
  .delete(protect, deleteCrop);

module.exports = router;