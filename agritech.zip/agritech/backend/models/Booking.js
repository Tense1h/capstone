const mongoose = require('mongoose');

const bookingSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  product: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Product',
  },
  bookingType: {
    type: String,
    enum: ['product_purchase', 'equipment_rental', 'expert_consultation', 'soil_testing', 'labor_hire'],
    required: true,
  },
  quantity: {
    type: Number,
    default: 1,
    min: 1,
  },
  rentalDuration: {
    startDate: Date,
    endDate: Date,
  },
  consultationDate: Date,
  expert: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
  },
  totalAmount: {
    type: Number,
    required: true,
  },
  status: {
    type: String,
    enum: ['pending', 'confirmed', 'in_progress', 'completed', 'cancelled', 'refunded'],
    default: 'pending',
  },
  paymentStatus: {
    type: String,
    enum: ['pending', 'paid', 'failed', 'refunded'],
    default: 'pending',
  },
  paymentMethod: String,
  transactionId: String,
  deliveryAddress: {
    address: String,
    city: String,
    state: String,
    pincode: String,
  },
  specialInstructions: String,
  scheduledDate: Date,
  completedDate: Date,
}, {
  timestamps: true,
});

module.exports = mongoose.model('Booking', bookingSchema);