/**
 * create-admin.js
 * Creates the default admin account.
 * Run once:  node create-admin.js
 *
 * Credentials:
 *   Email   : admin@agritech.com
 *   Password: Admin@1234
 */

const dns = require('dns');
dns.setServers(['8.8.8.8', '8.8.4.4']);
dns.setDefaultResultOrder('ipv4first');

require('dotenv').config({ path: require('path').join(__dirname, '.env') });
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const ADMIN = {
  name:       'Admin',
  email:      'admin@agritech.com',
  password:   'Admin@1234',
  role:       'admin',
  isVerified: true,
};

async function run() {
  console.log('🔌 Connecting to MongoDB...');
  await mongoose.connect(process.env.MONGODB_URI);
  console.log('✅ Connected:', mongoose.connection.host);

  const db    = mongoose.connection.db;
  const users = db.collection('users');

  // Check if admin already exists
  const existing = await users.findOne({ email: ADMIN.email });
  if (existing) {
    console.log('⚠️  Admin account already exists:', ADMIN.email);
    await mongoose.disconnect();
    return;
  }

  // Hash password
  const salt           = await bcrypt.genSalt(10);
  const hashedPassword = await bcrypt.hash(ADMIN.password, salt);

  await users.insertOne({
    name:           ADMIN.name,
    email:          ADMIN.email,
    password:       hashedPassword,
    role:           ADMIN.role,
    isVerified:     ADMIN.isVerified,
    phone:          '',
    profilePicture: '',
    bio:            '',
    farmExperience: '',
    location:       { city: '', state: '', pincode: '' },
    createdAt:      new Date(),
    updatedAt:      new Date(),
  });

  console.log('\n✅ Admin account created!');
  console.log('─────────────────────────────');
  console.log('  Email   :', ADMIN.email);
  console.log('  Password:', ADMIN.password);
  console.log('─────────────────────────────');
  console.log('Login at http://localhost:5173/login\n');

  await mongoose.disconnect();
}

run().catch(err => {
  console.error('❌ Failed:', err.message);
  process.exit(1);
});
